<?php
/**
 * Plugin Name: July 3 Global Mobilization & 101 Demands Core
 * Plugin URI:  https://101demands.org
 * Description: Open-Source (FOSS) multi-country mobilization engine: Assemblies Map (OpenStreetMap), Coalition Logo Wall, Deliberative 101 Demands Voting Deck with Live Duplicate Matcher, and Country-Scoped CRM + CSV Exporter. Zero third-party trackers.
 * Version:     0.2.0
 * Author:      101 Demands Global Tech Collective
 * License:     GPL-3.0+
 * Text Domain: july3-core
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * ============================================================================
 * MODULE 1: CUSTOM POST TYPES & GLOBAL TAXONOMIES (Non-Eurocentric / Multilingual)
 * ============================================================================
 */
add_action( 'init', function() {

    // Shared Taxonomy 1: Country / Region (Used across Hubs, Orgs, and Demands for Country CRM scoping)
    register_taxonomy( 'mobilization_region', [ 'mobilization_hub', 'mobilization_org', 'mobilization_demand' ], [
        'labels'            => [
            'name'          => __( 'Countries & Regions', 'july3-core' ),
            'singular_name' => __( 'Country / Region', 'july3-core' ),
            'add_new_item'  => __( 'Add New Country / Region', 'july3-core' ),
        ],
        'public'            => true,
        'hierarchical'      => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,
    ]);

    // Shared Taxonomy 2: Thematic Pillars & Sectors (Organic / Global Majority inclusive)
    register_taxonomy( 'mobilization_pillar', [ 'mobilization_demand', 'mobilization_org' ], [
        'labels'            => [
            'name'          => __( 'Pillars & Sectors', 'july3-core' ),
            'singular_name' => __( 'Pillar / Sector', 'july3-core' ),
            'add_new_item'  => __( 'Add New Pillar / Sector', 'july3-core' ),
        ],
        'public'            => true,
        'hierarchical'      => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,
    ]);

    // CPT 1: Assemblies & Map Hubs (Tracks A, B, and C: Prep, Confirmed, & July 3 Capital Convergences)
    register_post_type( 'mobilization_hub', [
        'labels'       => [
            'name'          => __( 'Assemblies & Map', 'july3-core' ),
            'singular_name' => __( 'Assembly / Hub', 'july3-core' ),
            'add_new_item'  => __( 'Add New Assembly or Capital City Hub', 'july3-core' ),
        ],
        'public'       => true,
        'menu_icon'    => 'dashicons-location-alt',
        'supports'     => [ 'title', 'editor', 'custom-fields' ],
        'show_in_rest' => true,
    ]);

    // CPT 2: Coalition Organisations & NGOs ("Massive Logo Wall")
    register_post_type( 'mobilization_org', [
        'labels'       => [
            'name'          => __( 'Coalition Orgs', 'july3-core' ),
            'singular_name' => __( 'Coalition Organisation', 'july3-core' ),
            'add_new_item'  => __( 'Add Coalition Organisation', 'july3-core' ),
        ],
        'public'       => true,
        'menu_icon'    => 'dashicons-groups',
        'supports'     => [ 'title', 'thumbnail', 'custom-fields' ],
        'show_in_rest' => true,
    ]);

    // CPT 3: 101 Demands & Living Constitution Proposals
    register_post_type( 'mobilization_demand', [
        'labels'       => [
            'name'          => __( '101 Demands', 'july3-core' ),
            'singular_name' => __( 'Demand / Measure', 'july3-core' ),
            'add_new_item'  => __( 'Add New Demand / Measure', 'july3-core' ),
        ],
        'public'       => true,
        'menu_icon'    => 'dashicons-megaphone',
        'supports'     => [ 'title', 'editor', 'excerpt', 'custom-fields' ],
        'show_in_rest' => true,
    ]);
});

/**
 * ============================================================================
 * MODULE 2: ADMIN META BOXES (Assemblies, Orgs CRM, & Two-Tier Demand Weighting)
 * ============================================================================
 */
add_action( 'add_meta_boxes', function() {

    // Meta Box 1: Assembly & Capital City Hub Details
    add_meta_box( 'july3_hub_meta', __( 'Assembly, Map Coordinates & Private Host CRM', 'july3-core' ), function( $post ) {
        wp_nonce_field( 'july3_save_meta', 'july3_nonce' );
        $type      = get_post_meta( $post->ID, '_hub_type', true ) ?: 'confirmed';
        $lat       = get_post_meta( $post->ID, '_hub_lat', true );
        $lng       = get_post_meta( $post->ID, '_hub_lng', true );
        $meetup    = get_post_meta( $post->ID, '_hub_meetup', true );
        $chat      = get_post_meta( $post->ID, '_hub_chat_url', true );
        $next_date = get_post_meta( $post->ID, '_hub_next_date', true );
        $pledges   = (int) get_post_meta( $post->ID, '_hub_pledges', true );
        $threshold = (int) ( get_post_meta( $post->ID, '_hub_threshold', true ) ?: 500 );
        $host_email= get_post_meta( $post->ID, '_crm_host_email', true );
        $host_phone= get_post_meta( $post->ID, '_crm_host_phone', true );
        ?>
        <p><label><strong>Hub Track / Status:</strong></label><br>
            <select name="hub_type" style="width:100%;max-width:450px;">
                <option value="prep" <?php selected( $type, 'prep' ); ?>>⏳ Track A: Local Assembly in Preparation (Seeking Co-Hosts)</option>
                <option value="confirmed" <?php selected( $type, 'confirmed' ); ?>>✅ Track B: Confirmed Local Citizen Assembly</option>
                <option value="capital" <?php selected( $type, 'capital' ); ?>>🔥 Track C: July 3 Capital / Major City Mass Convergence</option>
            </select>
        </p>
        <p><label><strong>Latitude & Longitude (e.g. 4.7110, -74.0721 for Bogotá):</strong></label><br>
            <input type="text" name="hub_lat" placeholder="Latitude" value="<?php echo esc_attr( $lat ); ?>" style="width:48%;">
            <input type="text" name="hub_lng" placeholder="Longitude" value="<?php echo esc_attr( $lng ); ?>" style="width:48%;">
        </p>
        <p><label><strong>Public Meeting Point / Assembly Info:</strong></label><br>
            <input type="text" name="hub_meetup" value="<?php echo esc_attr( $meetup ); ?>" style="width:100%;">
        </p>
        <p><label><strong>Next Assembly / Milestone Date (e.g., March 20-21 Global Link-Up):</strong></label><br>
            <input type="text" name="hub_next_date" value="<?php echo esc_attr( $next_date ); ?>" style="width:100%;">
        </p>
        <p><label><strong>Public Group Link (Signal / Telegram / WhatsApp):</strong></label><br>
            <input type="url" name="hub_chat_url" value="<?php echo esc_url( $chat ); ?>" style="width:100%;">
        </p>
        <p><label><strong>July 3rd Pledges & Public Visibility Threshold (Hides count until threshold met):</strong></label><br>
            Pledges: <input type="number" name="hub_pledges" value="<?php echo esc_attr( $pledges ); ?>" style="width:120px;">
            Unlock Threshold: <input type="number" name="hub_threshold" value="<?php echo esc_attr( $threshold ); ?>" style="width:120px;">
        </p>
        <hr>
        <p style="color:#b91c1c;"><strong>🔒 PRIVATE COUNTRY CRM FIELDS (Never shown on public map):</strong></p>
        <p>Host Email: <input type="email" name="crm_host_email" value="<?php echo esc_attr( $host_email ); ?>" style="width:40%;">
           Host Phone/Signal: <input type="text" name="crm_host_phone" value="<?php echo esc_attr( $host_phone ); ?>" style="width:40%;"></p>
        <?php
    }, 'mobilization_hub', 'normal', 'high' );

    // Meta Box 2: Coalition Org Website, Logo URL & Private Contact CRM
    add_meta_box( 'july3_org_meta', __( 'Coalition Organisation Details & Private CRM', 'july3-core' ), function( $post ) {
        wp_nonce_field( 'july3_save_meta', 'july3_nonce' );
        $web   = get_post_meta( $post->ID, '_org_website', true );
        $logo  = get_post_meta( $post->ID, '_org_logo_url', true );
        $cname = get_post_meta( $post->ID, '_crm_org_contact', true );
        $cmail = get_post_meta( $post->ID, '_crm_org_email', true );
        ?>
        <p><label><strong>Public Website URL:</strong></label><br>
            <input type="url" name="org_website" value="<?php echo esc_url( $web ); ?>" style="width:100%;"></p>
        <p><label><strong>Logo Image URL (or set via Featured Image on the right):</strong></label><br>
            <input type="url" name="org_logo_url" value="<?php echo esc_url( $logo ); ?>" style="width:100%;"></p>
        <hr>
        <p style="color:#b91c1c;"><strong>🔒 PRIVATE COUNTRY CRM FIELDS (Hidden from public):</strong></p>
        <p>Coordinator Name: <input type="text" name="crm_org_contact" value="<?php echo esc_attr( $cname ); ?>" style="width:40%;">
           Coordinator Email: <input type="email" name="crm_org_email" value="<?php echo esc_attr( $cmail ); ?>" style="width:40%;"></p>
        <?php
    }, 'mobilization_org', 'normal', 'high' );

    // Meta Box 3: Demand Deliberative Assembly Backing vs. Online Pulse Votes
    add_meta_box( 'july3_demand_meta', __( 'Consensus Metrics (Deliberative Assemblies vs. Online Pulse)', 'july3-core' ), function( $post ) {
        wp_nonce_field( 'july3_save_meta', 'july3_nonce' );
        $origin     = get_post_meta( $post->ID, '_demand_origin', true ) ?: 'Proposed by Citizen Assembly';
        $assemblies = (int) get_post_meta( $post->ID, '_demand_assemblies_count', true ) ?: 1;
        $agree      = (int) get_post_meta( $post->ID, '_demand_votes_agree', true );
        $disagree   = (int) get_post_meta( $post->ID, '_demand_votes_disagree', true );
        $is_const   = get_post_meta( $post->ID, '_demand_in_constitution', true );
        ?>
        <p><label><strong>Origin Badge (e.g., "Proposed by Nairobi Assembly" or "The 101st Demand"):</strong></label><br>
            <input type="text" name="demand_origin" value="<?php echo esc_attr( $origin ); ?>" style="width:100%;"></p>
        <p><label><strong>🏛️ PRIMARY DRIVER — Number of Verified Physical Assemblies Endorsing:</strong></label><br>
            <input type="number" name="demand_assemblies_count" value="<?php echo esc_attr( $assemblies ); ?>" style="width:140px;"></p>
        <p><label><strong>🗳️ SECONDARY TEMPERATURE CHECK — Online Citizen Pulse Votes:</strong></label><br>
            👍 Agree: <input type="number" name="demand_votes_agree" value="<?php echo esc_attr( $agree ); ?>" style="width:110px;">
            👎 Disagree: <input type="number" name="demand_votes_disagree" value="<?php echo esc_attr( $disagree ); ?>" style="width:110px;"></p>
        <p><label><input type="checkbox" name="demand_in_constitution" value="yes" <?php checked( $is_const, 'yes' ); ?>>
            <strong>📜 Graduated to Draft People's Constitution (Supermajority Consensus)</strong></label></p>
        <?php
    }, 'mobilization_demand', 'normal', 'high' );
});

// Save Meta Box Data Safely
add_action( 'save_post', function( $post_id ) {
    if ( ! isset( $_POST['july3_nonce'] ) || ! wp_verify_nonce( $_POST['july3_nonce'], 'july3_save_meta' ) ) return;
    $fields = [
        'hub_type' => '_hub_type', 'hub_lat' => '_hub_lat', 'hub_lng' => '_hub_lng',
        'hub_meetup' => '_hub_meetup', 'hub_next_date' => '_hub_next_date', 'hub_chat_url' => '_hub_chat_url',
        'hub_pledges' => '_hub_pledges', 'hub_threshold' => '_hub_threshold',
        'crm_host_email' => '_crm_host_email', 'crm_host_phone' => '_crm_host_phone',
        'org_website' => '_org_website', 'org_logo_url' => '_org_logo_url',
        'crm_org_contact' => '_crm_org_contact', 'crm_org_email' => '_crm_org_email',
        'demand_origin' => '_demand_origin', 'demand_assemblies_count' => '_demand_assemblies_count',
        'demand_votes_agree' => '_demand_votes_agree', 'demand_votes_disagree' => '_demand_votes_disagree',
    ];
    foreach ( $fields as $input => $meta_key ) {
        if ( isset( $_POST[ $input ] ) ) {
            update_post_meta( $post_id, $meta_key, sanitize_text_field( wp_unslash( $_POST[ $input ] ) ) );
        }
    }
    if ( get_post_type( $post_id ) === 'mobilization_demand' ) {
        update_post_meta( $post_id, '_demand_in_constitution', isset( $_POST['demand_in_constitution'] ) ? 'yes' : 'no' );
    }
});

/**
 * ============================================================================
 * MODULE 3: AJAX ENDPOINTS FOR VOTING & FRONTEND SUBMISSIONS
 * ============================================================================
 */
add_action( 'wp_ajax_july3_cast_vote', 'july3_handle_vote' );
add_action( 'wp_ajax_nopriv_july3_cast_vote', 'july3_handle_vote' );
function july3_handle_vote() {
    $post_id = (int) ( $_POST['post_id'] ?? 0 );
    $vote    = sanitize_text_field( $_POST['vote'] ?? '' );
    if ( $post_id && in_array( $vote, [ 'agree', 'disagree' ], true ) ) {
        $key = $vote === 'agree' ? '_demand_votes_agree' : '_demand_votes_disagree';
        $cur = (int) get_post_meta( $post_id, $key, true );
        update_post_meta( $post_id, $key, $cur + 1 );
    }
    $a = (int) get_post_meta( $post_id, '_demand_votes_agree', true );
    $d = (int) get_post_meta( $post_id, '_demand_votes_disagree', true );
    $tot = max( 1, $a + $d );
    wp_send_json_success([ 'agree' => $a, 'disagree' => $d, 'pct' => round( ( $a / $tot ) * 100 ) ]);
}

/**
 * ============================================================================
 * MODULE 4: SHORTCODE 1 — [mobilization_map] (OpenStreetMap + 3 Pin Tracks)
 * ============================================================================
 */
add_shortcode( 'mobilization_map', function() {
    wp_enqueue_style( 'leaflet-css', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', [], '1.9.4' );
    wp_enqueue_script( 'leaflet-js', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', [], '1.9.4', true );

    $hubs = get_posts([ 'post_type' => 'mobilization_hub', 'posts_per_page' => -1, 'post_status' => 'publish' ]);
    $pins = [];
    foreach ( $hubs as $h ) {
        $lat = get_post_meta( $h->ID, '_hub_lat', true );
        $lng = get_post_meta( $h->ID, '_hub_lng', true );
        if ( $lat && $lng ) {
            $pledges   = (int) get_post_meta( $h->ID, '_hub_pledges', true );
            $threshold = (int) ( get_post_meta( $h->ID, '_hub_threshold', true ) ?: 500 );
            $pins[] = [
                'title'   => $h->post_title,
                'lat'     => (float) $lat,
                'lng'     => (float) $lng,
                'type'    => get_post_meta( $h->ID, '_hub_type', true ) ?: 'confirmed',
                'meetup'  => get_post_meta( $h->ID, '_hub_meetup', true ),
                'date'    => get_post_meta( $h->ID, '_hub_next_date', true ),
                'chat'    => get_post_meta( $h->ID, '_hub_chat_url', true ),
                'pledges' => ( $pledges >= $threshold ) ? $pledges : 0,
            ];
        }
    }

    ob_start(); ?>
    <div class="july3-map-wrap" style="margin:24px 0;font-family:system-ui,sans-serif;">
        <div style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:12px;align-items:center;">
            <strong>🌍 Filter Map:</strong>
            <button type="button" onclick="july3FilterMap('all')" style="padding:6px 14px;border:2px solid #111;border-radius:99px;background:#111;color:#fff;cursor:pointer;font-weight:700;">All Global Pins</button>
            <button type="button" onclick="july3FilterMap('capital')" style="padding:6px 14px;border:2px solid #111;border-radius:99px;background:#fee2e2;color:#991b1b;cursor:pointer;font-weight:700;">🔥 July 3 Capital Convergences</button>
            <button type="button" onclick="july3FilterMap('confirmed')" style="padding:6px 14px;border:2px solid #111;border-radius:99px;background:#d1fae5;color:#065f46;cursor:pointer;font-weight:700;">✅ Confirmed Assemblies</button>
            <button type="button" onclick="july3FilterMap('prep')" style="padding:6px 14px;border:2px solid #111;border-radius:99px;background:#fef3c7;color:#92400e;cursor:pointer;font-weight:700;">⏳ In Preparation</button>
        </div>
        <div id="july3-osm-map" style="height:500px;width:100%;border-radius:14px;border:2px solid #111;box-shadow:4px 4px 0 #111;"></div>
    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var map = L.map('july3-osm-map').setView([20.0, 10.0], 2);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        var rawPins = <?php echo wp_json_encode( $pins ); ?>;
        var markers = [];

        window.july3FilterMap = function(filterType) {
            markers.forEach(function(m) { map.removeLayer(m); });
            markers = [];
            rawPins.forEach(function(p) {
                if (filterType !== 'all' && p.type !== filterType) return;
                var color = p.type === 'capital' ? '#e11d48' : (p.type === 'confirmed' ? '#059669' : '#f59e0b');
                var radius = p.type === 'capital' ? 12 : 8;
                var m = L.circleMarker([p.lat, p.lng], {
                    radius: radius, fillColor: color, color: '#111', weight: 2, fillOpacity: 0.92
                }).addTo(map);
                var badge = p.type === 'capital' ? '🔥 July 3 Capital Convergence' : (p.type === 'confirmed' ? '✅ Confirmed Assembly' : '⏳ Assembly in Prep');
                var html = '<div style="font-family:system-ui;line-height:1.4;"><strong>' + p.title + '</strong><br><span style="font-size:12px;color:#4b5563;">' + badge + '</span><br>';
                if (p.meetup) html += '📍 ' + p.meetup + '<br>';
                if (p.date) html += '🗓️ ' + p.date + '<br>';
                if (p.pledges > 0) html += '✋ <strong>' + p.pledges + '+</strong> Pledged for July 3<br>';
                if (p.chat) html += '<a href="' + p.chat + '" target="_blank" rel="noopener" style="display:inline-block;margin-top:6px;padding:4px 10px;background:#111;color:#fff;text-decoration:none;border-radius:6px;font-size:12px;">💬 Join Local Group</a>';
                html += '</div>';
                m.bindPopup(html);
                markers.push(m);
            });
        };
        july3FilterMap('all');
    });
    </script>
    <?php
    return ob_get_clean();
});

/**
 * ============================================================================
 * MODULE 5: SHORTCODE 2 — [demands_voting_deck] (Live Duplicate Catcher + Cards)
 * ============================================================================
 */
add_shortcode( 'demands_voting_deck', function() {
    $demands = get_posts([ 'post_type' => 'mobilization_demand', 'posts_per_page' => -1, 'post_status' => 'publish' ]);
    $items   = [];
    foreach ( $demands as $d ) {
        $a   = (int) get_post_meta( $d->ID, '_demand_votes_agree', true );
        $dis = (int) get_post_meta( $d->ID, '_demand_votes_disagree', true );
        $tot = max( 1, $a + $dis );
        $items[] = [
            'id'         => $d->ID,
            'title'      => $d->post_title,
            'content'    => wp_strip_all_tags( $d->post_excerpt ?: $d->post_content ),
            'origin'     => get_post_meta( $d->ID, '_demand_origin', true ) ?: 'Proposed by Citizen Assembly',
            'assemblies' => (int) ( get_post_meta( $d->ID, '_demand_assemblies_count', true ) ?: 1 ),
            'agree'      => $a,
            'pct'        => round( ( $a / $tot ) * 100 ),
        ];
    }
    ob_start(); ?>
    <div class="july3-voting-engine" style="margin:30px 0;font-family:system-ui,sans-serif;">
        <!-- Type-First Live Duplicate Matcher -->
        <div style="background:#f3f4f6;border:2px solid #111;border-radius:12px;padding:20px;margin-bottom:24px;box-shadow:4px 4px 0 #111;">
            <label for="july3-demand-search" style="display:block;font-weight:800;font-size:18px;margin-bottom:8px;">
                🔍 What must be in the People's Constitution? Start typing your demand:
            </label>
            <input type="text" id="july3-demand-search" placeholder="e.g., Cancel illegitimate debt, tax superprofits, binding citizen assemblies..." style="width:100%;padding:12px 16px;font-size:16px;border:2px solid #111;border-radius:8px;box-sizing:border-box;">
            <div id="july3-duplicate-matches" style="margin-top:12px;display:none;"></div>
        </div>

        <!-- Deliberative Micro-Deck Voting Grid -->
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:20px;">
            <?php foreach ( $items as $item ) : ?>
                <div class="july3-demand-card" data-title="<?php echo esc_attr( strtolower( $item['title'] . ' ' . $item['content'] ) ); ?>" style="border:2px solid #111;border-radius:12px;padding:20px;background:#fff;box-shadow:4px 4px 0 #111;display:flex;flex-direction:column;justify-content:space-between;">
                    <div>
                        <div style="font-size:12px;font-weight:800;color:#e11d48;text-transform:uppercase;letter-spacing:0.5px;">
                            🏛️ Backed by <?php echo esc_html( $item['assemblies'] ); ?> Assemblies • <?php echo esc_html( $item['origin'] ); ?>
                        </div>
                        <h3 style="margin:10px 0;font-size:19px;line-height:1.35;"><?php echo esc_html( $item['title'] ); ?></h3>
                        <?php if ( $item['content'] ) : ?>
                            <p style="font-size:14px;color:#4b5563;line-height:1.5;"><?php echo esc_html( $item['content'] ); ?></p>
                        <?php endif; ?>
                    </div>
                    <div style="margin-top:16px;padding-top:12px;border-top:1px solid #e5e7eb;">
                        <div id="july3-vote-bar-<?php echo esc_attr( $item['id'] ); ?>" style="font-size:13px;font-weight:700;color:#059669;margin-bottom:10px;">
                            📊 Online Citizen Pulse: <?php echo esc_html( $item['pct'] ); ?>% Agree (<?php echo esc_html( $item['agree'] ); ?> 👍)
                        </div>
                        <div style="display:flex;gap:8px;">
                            <button type="button" onclick="july3Vote(<?php echo esc_attr( $item['id'] ); ?>,'agree',this)" style="flex:1;padding:8px;background:#d1fae5;border:2px solid #059669;border-radius:8px;font-weight:700;cursor:pointer;">👍 Agree</button>
                            <button type="button" onclick="july3Vote(<?php echo esc_attr( $item['id'] ); ?>,'disagree',this)" style="flex:1;padding:8px;background:#fee2e2;border:2px solid #e11d48;border-radius:8px;font-weight:700;cursor:pointer;">👎 Disagree</button>
                            <button type="button" onclick="this.closest('.july3-demand-card').style.opacity='0.4';" style="padding:8px 12px;background:#f3f4f6;border:2px solid #6b7280;border-radius:8px;cursor:pointer;">⏭️ Skip</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <script>
    (function(){
        var searchInput = document.getElementById('july3-demand-search');
        var matchBox = document.getElementById('july3-duplicate-matches');
        if (searchInput) {
            searchInput.addEventListener('input', function() {
                var q = this.value.toLowerCase().trim();
                var cards = document.querySelectorAll('.july3-demand-card');
                var matches = 0;
                cards.forEach(function(c) {
                    var text = c.getAttribute('data-title') || '';
                    if (!q || text.indexOf(q) !== -1) {
                        c.style.display = 'flex';
                        if (q.length > 2) matches++;
                    } else {
                        c.style.display = 'none';
                    }
                });
                if (q.length > 2) {
                    matchBox.style.display = 'block';
                    matchBox.innerHTML = matches > 0
                        ? '✨ <strong>Found ' + matches + ' similar assembly proposal(s) below!</strong> Upvote an existing demand below to build consensus, or submit yours if it is brand new.'
                        : '💡 <strong>No exact match yet!</strong> Your assembly or group can submit <em>"' + this.value.replace(/</g,'&lt;') + '"</em> as a new proposal.';
                } else {
                    matchBox.style.display = 'none';
                }
            });
        }
        window.july3Vote = function(postId, voteType, btn) {
            var fd = new FormData();
            fd.append('action', 'july3_cast_vote');
            fd.append('post_id', postId);
            fd.append('vote', voteType);
            fetch('<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>', { method: 'POST', body: fd })
                .then(function(r){ return r.json(); })
                .then(function(res){
                    if (res.success) {
                        var bar = document.getElementById('july3-vote-bar-' + postId);
                        if (bar) bar.innerHTML = '✅ Vote recorded! Online Pulse: ' + res.data.pct + '% Agree (' + res.data.agree + ' 👍)';
                        btn.disabled = true;
                    }
                });
        };
    })();
    </script>
    <?php
    return ob_get_clean();
});

/**
 * ============================================================================
 * MODULE 6: SHORTCODE 3 — [coalition_logo_wall] (Filterable Logo Grid)
 * ============================================================================
 */
add_shortcode( 'coalition_logo_wall', function() {
    $orgs = get_posts([ 'post_type' => 'mobilization_org', 'posts_per_page' => -1, 'post_status' => 'publish' ]);
    ob_start(); ?>
    <div class="july3-logo-wall" style="margin:30px 0;font-family:system-ui,sans-serif;">
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:16px;">
            <?php foreach ( $orgs as $o ) :
                $web  = get_post_meta( $o->ID, '_org_website', true ) ?: '#';
                $logo = get_the_post_thumbnail_url( $o->ID, 'medium' ) ?: get_post_meta( $o->ID, '_org_logo_url', true );
                ?>
                <a href="<?php echo esc_url( $web ); ?>" target="_blank" rel="noopener" style="border:2px solid #111;border-radius:10px;padding:16px;background:#fff;display:flex; flex-direction:column;align-items:center;justify-content:center;text-decoration:none;color:#111;box-shadow:3px 3px 0 #111;min-height:100px;text-align:center;">
                    <?php if ( $logo ) : ?>
                        <img src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( $o->post_title ); ?>" loading="lazy" style="max-width:130px;max-height:65px;object-fit:contain;margin-bottom:8px;">
                    <?php endif; ?>
                    <strong style="font-size:13px;"><?php echo esc_html( $o->post_title ); ?></strong>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
});

/**
 * ============================================================================
 * MODULE 7: MULTI-TENANT COUNTRY CRM & 1-CLICK CSV EXPORTER (WP Admin)
 * ============================================================================
 */
add_action( 'admin_menu', function() {
    add_menu_page(
        __( 'Country CRM & CSV Export', 'july3-core' ),
        __( '🌍 Country CRM', 'july3-core' ),
        'edit_posts',
        'july3-country-crm',
        'july3_render_crm_page',
        'dashicons-download',
        25
    );
});

add_action( 'admin_init', function() {
    if ( isset( $_GET['july3_export_csv'] ) && current_user_can( 'edit_posts' ) ) {
        check_admin_referer( 'july3_csv_export' );
        $type   = sanitize_text_field( $_GET['july3_export_csv'] );
        $region = sanitize_text_field( $_GET['region_slug'] ?? '' );

        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="101demands-' . $type . '-' . ( $region ?: 'global' ) . '-' . gmdate( 'Y-m-d' ) . '.csv"' );
        $out = fopen( 'php://output', 'w' );

        $args = [ 'post_type' => $type, 'posts_per_page' => -1, 'post_status' => 'any' ];
        if ( $region ) {
            $args['tax_query'] = [[ 'taxonomy' => 'mobilization_region', 'field' => 'slug', 'terms' => $region ]];
        }
        $posts = get_posts( $args );

        if ( $type === 'mobilization_hub' ) {
            fputcsv( $out, [ 'ID', 'Hub / City', 'Track Status', 'Region', 'Lat', 'Lng', 'Meeting Info', 'Next Date', 'Public Chat', 'July 3 Pledges', 'Private Host Email', 'Private Host Phone' ] );
            foreach ( $posts as $p ) {
                $regs = wp_get_post_terms( $p->ID, 'mobilization_region', [ 'fields' => 'names' ] );
                fputcsv( $out, [
                    $p->ID, $p->post_title, get_post_meta( $p->ID, '_hub_type', true ), implode( ', ', $regs ),
                    get_post_meta( $p->ID, '_hub_lat', true ), get_post_meta( $p->ID, '_hub_lng', true ),
                    get_post_meta( $p->ID, '_hub_meetup', true ), get_post_meta( $p->ID, '_hub_next_date', true ),
                    get_post_meta( $p->ID, '_hub_chat_url', true ), get_post_meta( $p->ID, '_hub_pledges', true ),
                    get_post_meta( $p->ID, '_crm_host_email', true ), get_post_meta( $p->ID, '_crm_host_phone', true ),
                ]);
            }
        } elseif ( $type === 'mobilization_org' ) {
            fputcsv( $out, [ 'ID', 'Organisation Name', 'Status', 'Region', 'Sector', 'Website', 'Private Coordinator Name', 'Private Coordinator Email' ] );
            foreach ( $posts as $p ) {
                $regs = wp_get_post_terms( $p->ID, 'mobilization_region', [ 'fields' => 'names' ] );
                $secs = wp_get_post_terms( $p->ID, 'mobilization_pillar', [ 'fields' => 'names' ] );
                fputcsv( $out, [
                    $p->ID, $p->post_title, $p->post_status, implode( ', ', $regs ), implode( ', ', $secs ),
                    get_post_meta( $p->ID, '_org_website', true ),
                    get_post_meta( $p->ID, '_crm_org_contact', true ), get_post_meta( $p->ID, '_crm_org_email', true ),
                ]);
            }
        } elseif ( $type === 'mobilization_demand' ) {
            fputcsv( $out, [ 'ID', 'Demand Title', 'Region', 'Pillar', 'Origin', 'Verified Assemblies Count', 'Online Agree Votes', 'Online Disagree Votes', 'In Draft Constitution' ] );
            foreach ( $posts as $p ) {
                $regs = wp_get_post_terms( $p->ID, 'mobilization_region', [ 'fields' => 'names' ] );
                $pils = wp_get_post_terms( $p->ID, 'mobilization_pillar', [ 'fields' => 'names' ] );
                fputcsv( $out, [
                    $p->ID, $p->post_title, implode( ', ', $regs ), implode( ', ', $pils ),
                    get_post_meta( $p->ID, '_demand_origin', true ), get_post_meta( $p->ID, '_demand_assemblies_count', true ),
                    get_post_meta( $p->ID, '_demand_votes_agree', true ), get_post_meta( $p->ID, '_demand_votes_disagree', true ),
                    get_post_meta( $p->ID, '_demand_in_constitution', true ),
                ]);
            }
        }
        fclose( $out );
        exit;
    }
});

function july3_render_crm_page() {
    $regions = get_terms([ 'taxonomy' => 'mobilization_region', 'hide_empty' => false ]);
    ?>
    <div class="wrap">
        <h1>🌍 101 Demands — Multi-Country CRM & CSV Data Exporter</h1>
        <p>Select a Country/Region below (or leave as Global) to export CSV spreadsheets of Assemblies, Coalition Orgs (including private coordinator contacts), and Demand Consensus metrics.</p>
        <div style="background:#fff;border:2px solid #111;border-radius:10px;padding:24px;max-width:750px;margin-top:20px;">
            <form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
                <input type="hidden" name="page" value="july3-country-crm">
                <?php wp_nonce_field( 'july3_csv_export' ); ?>
                <p><label><strong>1. Filter by Country / Region:</strong></label><br>
                    <select name="region_slug" style="min-width:280px;margin-top:6px;">
                        <option value="">🌍 All Regions (Global Export)</option>
                        <?php if ( ! is_wp_error( $regions ) ) : foreach ( $regions as $r ) : ?>
                            <option value="<?php echo esc_attr( $r->slug ); ?>"><?php echo esc_html( $r->name ); ?></option>
                        <?php endforeach; endif; ?>
                    </select>
                </p>
                <p style="margin-top:20px;"><strong>2. Click to Download CSV:</strong></p>
                <div style="display:flex;gap:12px;flex-wrap:wrap;">
                    <button type="submit" name="july3_export_csv" value="mobilization_hub" class="button button-primary">📥 Export Assemblies & Map Hubs (CSV)</button>
                    <button type="submit" name="july3_export_csv" value="mobilization_org" class="button button-primary">📥 Export Coalition Orgs & Contacts (CSV)</button>
                    <button type="submit" name="july3_export_csv" value="mobilization_demand" class="button button-primary">📥 Export 101 Demands & Votes (CSV)</button>
                </div>
            </form>
        </div>
    </div>
    <?php
}