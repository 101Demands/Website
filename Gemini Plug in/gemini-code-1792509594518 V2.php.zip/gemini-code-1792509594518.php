<?php
/**
 * Plugin Name: July 3 Global Mobilization & 101 Demands Core
 * Plugin URI:  https://101demands.org
 * Description: Open-Source (FOSS) mobilization engine: Assemblies & Town Hall Events Map (OpenStreetMap), Teamup Sync, Coalition Logo Wall, House of the People / 101 Demands Voting Deck, Pre-populated Global Countries, and Rebel House Style UI.
 * Version:     0.3.0
 * Author:      101 Demands Global Tech Collective
 * License:     GPL-3.0+
 * Text Domain: july3-core
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ============================================================================
 * MODULE 1: REGISTER CPTs, PRE-POPULATED COUNTRIES & AUTO-FLUSH PERMALINKS
 * ============================================================================
 */
function july3_register_all_types() {

    // Country / Region Taxonomy (Hierarchical = Checkbox list, no manual typing needed!)
    register_taxonomy( 'mobilization_region', [ 'mobilization_hub', 'mobilization_org', 'mobilization_demand' ], [
        'labels'            => [
            'name'          => __( 'Countries & Regions', 'july3-core' ),
            'singular_name' => __( 'Country / Region', 'july3-core' ),
            'search_items'  => __( 'Search Countries', 'july3-core' ),
            'all_items'     => __( 'All Countries', 'july3-core' ),
            'add_new_item'  => __( 'Add Country / Region', 'july3-core' ),
        ],
        'public'            => true,
        'hierarchical'      => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,
    ]);

    // Thematic Pillars & Sectors Taxonomy
    register_taxonomy( 'mobilization_pillar', [ 'mobilization_demand', 'mobilization_org' ], [
        'labels'            => [
            'name'          => __( 'Pillars & Sectors', 'july3-core' ),
            'singular_name' => __( 'Pillar / Sector', 'july3-core' ),
        ],
        'public'            => true,
        'hierarchical'      => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,
    ]);

    // CPT 1: Assemblies, Town Halls, Talks & Capital City Convergences
    register_post_type( 'mobilization_hub', [
        'labels'       => [
            'name'          => __( 'Assemblies & Events', 'july3-core' ),
            'singular_name' => __( 'Assembly / Event', 'july3-core' ),
            'add_new_item'  => __( 'Add Assembly, Town Hall or Event', 'july3-core' ),
        ],
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => [ 'slug' => 'assemblies' ],
        'menu_icon'    => 'dashicons-location-alt',
        'supports'     => [ 'title', 'editor', 'custom-fields' ],
        'show_in_rest' => true,
    ]);

    // CPT 2: Coalition Organisations ("Massive Logo Wall")
    register_post_type( 'mobilization_org', [
        'labels'       => [
            'name'          => __( 'Coalition Orgs', 'july3-core' ),
            'singular_name' => __( 'Coalition Organisation', 'july3-core' ),
            'add_new_item'  => __( 'Add Coalition Organisation', 'july3-core' ),
        ],
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => [ 'slug' => 'coalition' ],
        'menu_icon'    => 'dashicons-groups',
        'supports'     => [ 'title', 'editor', 'thumbnail', 'custom-fields' ],
        'show_in_rest' => true,
    ]);

    // CPT 3: 101 Demands & People's Charter Proposals
    register_post_type( 'mobilization_demand', [
        'labels'       => [
            'name'          => __( '101 Demands', 'july3-core' ),
            'singular_name' => __( 'Demand / Measure', 'july3-core' ),
            'add_new_item'  => __( 'Add New Demand / Measure', 'july3-core' ),
        ],
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => [ 'slug' => 'demands' ],
        'menu_icon'    => 'dashicons-megaphone',
        'supports'     => [ 'title', 'editor', 'excerpt', 'custom-fields' ],
        'show_in_rest' => true,
    ]);

    // Auto-flush rewrite rules once on version upgrade to prevent 404s!
    if ( get_option( 'july3_rewrite_version' ) !== '0.3.0' ) {
        flush_rewrite_rules();
        update_option( 'july3_rewrite_version', '0.3.0' );
    }
}
add_action( 'init', 'july3_register_all_types' );

/**
 * ============================================================================
 * MODULE 2: HOUSE STYLE & MODERN REBEL DESIGN ENGINE (Space Grotesk + Inter)
 * Removes narrow WP widths & harsh 1px borders; adds 26septembre-style sleekness
 * ============================================================================
 */
add_action( 'wp_head', function() {
    ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --j3-bg-dark: #0b0f19;
            --j3-bg-card-dark: #151c2c;
            --j3-crimson: #ff2a5f;
            --j3-emerald: #10b981;
            --j3-amber: #f59e0b;
            --j3-violet: #8b5cf6;
            --j3-slate: #f8fafc;
        }
        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif !important;
            background-color: #f8fafc;
            color: #0f172a;
        }
        h1, h2, h3, h4, .j3-display {
            font-family: 'Space Grotesk', sans-serif !important;
            letter-spacing: -0.02em;
        }
        /* Override Twenty Twenty-Five narrow 650px constraint so layout breathes */
        .wp-site-blocks main,
        .entry-content,
        .wp-block-post-content,
        .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)) {
            max-width: 1220px !important;
        }
        .j3-pill {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 18px;
            border-radius: 999px;
            font-weight: 600;
            font-size: 13px;
            border: none;
            cursor: pointer;
            transition: transform 0.15s ease, box-shadow 0.15s ease;
            box-shadow: 0 2px 10px rgba(15, 23, 42, 0.08);
        }
        .j3-pill:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(15, 23, 42, 0.14);
        }
        .j3-card {
            background: #ffffff;
            border-radius: 18px;
            padding: 26px;
            border: 1px solid rgba(15, 23, 42, 0.06);
            box-shadow: 0 12px 32px -8px rgba(15, 23, 42, 0.07);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .j3-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 20px 40px -12px rgba(15, 23, 42, 0.13);
        }
    </style>
    <?php
});

/**
 * ============================================================================
 * MODULE 3: ADMIN META BOXES (Supports Pre-Assembly Talks/Trainings + Teamup)
 * ============================================================================
 */
add_action( 'add_meta_boxes', function() {

    add_meta_box( 'july3_hub_meta', __( 'Assembly, Town Hall / Talk Details & Private CRM', 'july3-core' ), function( $post ) {
        wp_nonce_field( 'july3_save_meta', 'july3_nonce' );
        $type      = get_post_meta( $post->ID, '_hub_type', true ) ?: 'confirmed';
        $lat       = get_post_meta( $post->ID, '_hub_lat', true );
        $lng       = get_post_meta( $post->ID, '_hub_lng', true );
        $meetup    = get_post_meta( $post->ID, '_hub_meetup', true );
        $chat      = get_post_meta( $post->ID, '_hub_chat_url', true );
        $next_date = get_post_meta( $post->ID, '_hub_next_date', true );
        $pledges   = (int) get_post_meta( $post->ID, '_hub_pledges', true );
        $threshold = (int) ( get_post_meta( $post->ID, '_hub_threshold', true ) ?: 500 );
        $host_email= get_post_meta( $post->ID, '_crm_host_email', true );
        $host_phone= get_post_meta( $post->ID, '_crm_host_phone', true );
        ?>
        <p><label><strong>Event / Hub Track:</strong></label><br>
            <select name="hub_type" style="width:100%;max-width:520px;">
                <option value="event" <?php selected( $type, 'event' ); ?>>🎤 Public Talk / Town Hall / Training (Promoting Assemblies - e.g. Totnes)</option>
                <option value="prep" <?php selected( $type, 'prep' ); ?>>⏳ Local Assembly in Preparation (Seeking Co-Hosts)</option>
                <option value="confirmed" <?php selected( $type, 'confirmed' ); ?>>✅ Confirmed Citizen Assembly</option>
                <option value="capital" <?php selected( $type, 'capital' ); ?>>🔥 July 3 Capital / Major City Mass Convergence</option>
            </select>
        </p>
        <p><label><strong>Latitude & Longitude (e.g. 50.4312, -3.6844 for Totnes):</strong></label><br>
            <input type="text" name="hub_lat" placeholder="Latitude" value="<?php echo esc_attr( $lat ); ?>" style="width:48%;">
            <input type="text" name="hub_lng" placeholder="Longitude" value="<?php echo esc_attr( $lng ); ?>" style="width:48%;">
        </p>
        <p><label><strong>Venue / Location (e.g., Totnes Civic Hall, Totnes):</strong></label><br>
            <input type="text" name="hub_meetup" value="<?php echo esc_attr( $meetup ); ?>" style="width:100%;">
        </p>
        <p><label><strong>Date & Time (e.g., Fri 13 Nov 2026, 7:00pm - 9:30pm):</strong></label><br>
            <input type="text" name="hub_next_date" value="<?php echo esc_attr( $next_date ); ?>" style="width:100%;">
        </p>
        <p><label><strong>Event Link / Local Group Link (Teamup / Signal / Telegram / Ticket URL):</strong></label><br>
            <input type="url" name="hub_chat_url" value="<?php echo esc_url( $chat ); ?>" style="width:100%;">
        </p>
        <p><label><strong>July 3rd Pledges & Public Visibility Threshold:</strong></label><br>
            Pledges: <input type="number" name="hub_pledges" value="<?php echo esc_attr( $pledges ); ?>" style="width:120px;">
            Unlock Threshold: <input type="number" name="hub_threshold" value="<?php echo esc_attr( $threshold ); ?>" style="width:120px;">
        </p>
        <hr>
        <p style="color:#b91c1c;"><strong>🔒 PRIVATE COUNTRY CRM FIELDS (Hidden from public):</strong></p>
        <p>Host Email: <input type="email" name="crm_host_email" value="<?php echo esc_attr( $host_email ); ?>" style="width:40%;">
           Host Phone/Signal: <input type="text" name="crm_host_phone" value="<?php echo esc_attr( $host_phone ); ?>" style="width:40%;"></p>
        <?php
    }, 'mobilization_hub', 'normal', 'high' );

    add_meta_box( 'july3_org_meta', __( 'Coalition Organisation Details & Private CRM', 'july3-core' ), function( $post ) {
        wp_nonce_field( 'july3_save_meta', 'july3_nonce' );
        $web   = get_post_meta( $post->ID, '_org_website', true );
        $logo  = get_post_meta( $post->ID, '_org_logo_url', true );
        $cname = get_post_meta( $post->ID, '_crm_org_contact', true );
        $cmail = get_post_meta( $post->ID, '_crm_org_email', true );
        ?>
        <p><label><strong>Public Website URL:</strong></label><br>
            <input type="url" name="org_website" value="<?php echo esc_url( $web ); ?>" style="width:100%;"></p>
        <p><label><strong>Logo Image URL (or set via Featured Image in the right sidebar):</strong></label><br>
            <input type="url" name="org_logo_url" value="<?php echo esc_url( $logo ); ?>" style="width:100%;"></p>
        <hr>
        <p style="color:#b91c1c;"><strong>🔒 PRIVATE COUNTRY CRM FIELDS:</strong></p>
        <p>Coordinator Name: <input type="text" name="crm_org_contact" value="<?php echo esc_attr( $cname ); ?>" style="width:40%;">
           Coordinator Email: <input type="email" name="crm_org_email" value="<?php echo esc_attr( $cmail ); ?>" style="width:40%;"></p>
        <?php
    }, 'mobilization_org', 'normal', 'high' );

    add_meta_box( 'july3_demand_meta', __( 'Consensus Metrics (Deliberative Assemblies vs. Online Pulse)', 'july3-core' ), function( $post ) {
        wp_nonce_field( 'july3_save_meta', 'july3_nonce' );
        $origin     = get_post_meta( $post->ID, '_demand_origin', true ) ?: 'House of the People — The People\'s Charter';
        $assemblies = (int) get_post_meta( $post->ID, '_demand_assemblies_count', true ) ?: 1;
        $agree      = (int) get_post_meta( $post->ID, '_demand_votes_agree', true );
        $disagree   = (int) get_post_meta( $post->ID, '_demand_votes_disagree', true );
        $is_const   = get_post_meta( $post->ID, '_demand_in_constitution', true );
        ?>
        <p><label><strong>Origin Badge (e.g., "House of the People Charter" or "The 101st Demand"):</strong></label><br>
            <input type="text" name="demand_origin" value="<?php echo esc_attr( $origin ); ?>" style="width:100%;"></p>
        <p><label><strong>🏛️ PRIMARY DRIVER — Verified Assemblies Endorsing:</strong></label><br>
            <input type="number" name="demand_assemblies_count" value="<?php echo esc_attr( $assemblies ); ?>" style="width:140px;"></p>
        <p><label><strong>🗳️ SECONDARY TEMPERATURE CHECK — Online Citizen Pulse Votes:</strong></label><br>
            👍 Agree: <input type="number" name="demand_votes_agree" value="<?php echo esc_attr( $agree ); ?>" style="width:110px;">
            👎 Disagree: <input type="number" name="demand_votes_disagree" value="<?php echo esc_attr( $disagree ); ?>" style="width:110px;"></p>
        <p><label><input type="checkbox" name="demand_in_constitution" value="yes" <?php checked( $is_const, 'yes' ); ?>>
            <strong>📜 Graduated to Draft People's Constitution / Charter</strong></label></p>
        <?php
    }, 'mobilization_demand', 'normal', 'high' );
});

add_action( 'save_post', function( $post_id ) {
    if ( ! isset( $_POST['july3_nonce'] ) || ! wp_verify_nonce( $_POST['july3_nonce'], 'july3_save_meta' ) ) return;
    $fields = [
        'hub_type' => '_hub_type', 'hub_lat' => '_hub_lat', 'hub_lng' => '_hub_lng',
        'hub_meetup' => '_hub_meetup', 'hub_next_date' => '_hub_next_date', 'hub_chat_url' => '_hub_chat_url',
        'hub_pledges' => '_hub_pledges', 'hub_threshold' => '_hub_threshold',
        'crm_host_email' => '_crm_host_email', 'crm_host_phone' => '_crm_host_phone',
        'org_website' => '_org_website', 'org_logo_url' => '_org_logo_url',
        'crm_org_contact' => '_crm_org_contact', 'crm_org_email' => '_crm_org_email',
        'demand_origin' => '_demand_origin', 'demand_assemblies_count' => '_demand_assemblies_count',
        'demand_votes_agree' => '_demand_votes_agree', 'demand_votes_disagree' => '_demand_votes_disagree',
    ];
    foreach ( $fields as $input => $meta_key ) {
        if ( isset( $_POST[ $input ] ) ) {
            update_post_meta( $post_id, $meta_key, sanitize_text_field( wp_unslash( $_POST[ $input ] ) ) );
        }
    }
    if ( get_post_type( $post_id ) === 'mobilization_demand' ) {
        update_post_meta( $post_id, '_demand_in_constitution', isset( $_POST['demand_in_constitution'] ) ? 'yes' : 'no' );
    }
});

/**
 * ============================================================================
 * MODULE 4: AJAX VOTING ENDPOINT
 * ============================================================================
 */
add_action( 'wp_ajax_july3_cast_vote', 'july3_handle_vote' );
add_action( 'wp_ajax_nopriv_july3_cast_vote', 'july3_handle_vote' );
function july3_handle_vote() {
    $post_id = (int) ( $_POST['post_id'] ?? 0 );
    $vote    = sanitize_text_field( $_POST['vote'] ?? '' );
    if ( $post_id && in_array( $vote, [ 'agree', 'disagree' ], true ) ) {
        $key = $vote === 'agree' ? '_demand_votes_agree' : '_demand_votes_disagree';
        $cur = (int) get_post_meta( $post_id, $key, true );
        update_post_meta( $post_id, $key, $cur + 1 );
    }
    $a = (int) get_post_meta( $post_id, '_demand_votes_agree', true );
    $d = (int) get_post_meta( $post_id, '_demand_votes_disagree', true );
    $tot = max( 1, $a + $d );
    wp_send_json_success([ 'agree' => $a, 'disagree' => $d, 'pct' => round( ( $a / $tot ) * 100 ) ]);
}

/**
 * ============================================================================
 * MODULE 5: SHORTCODES (Map + Teamup Calendar + Voting Deck + Logo Wall)
 * ============================================================================
 */
add_shortcode( 'mobilization_map', function() {
    wp_enqueue_style( 'leaflet-css', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', [], '1.9.4' );
    wp_enqueue_script( 'leaflet-js', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', [], '1.9.4', true );

    $hubs = get_posts([ 'post_type' => 'mobilization_hub', 'posts_per_page' => -1, 'post_status' => 'publish' ]);
    $pins = [];
    foreach ( $hubs as $h ) {
        $lat = get_post_meta( $h->ID, '_hub_lat', true );
        $lng = get_post_meta( $h->ID, '_hub_lng', true );
        if ( $lat && $lng ) {
            $pledges   = (int) get_post_meta( $h->ID, '_hub_pledges', true );
            $threshold = (int) ( get_post_meta( $h->ID, '_hub_threshold', true ) ?: 500 );
            $pins[] = [
                'title'   => $h->post_title,
                'lat'     => (float) $lat,
                'lng'     => (float) $lng,
                'type'    => get_post_meta( $h->ID, '_hub_type', true ) ?: 'confirmed',
                'meetup'  => get_post_meta( $h->ID, '_hub_meetup', true ),
                'date'    => get_post_meta( $h->ID, '_hub_next_date', true ),
                'chat'    => get_post_meta( $h->ID, '_hub_chat_url', true ),
                'pledges' => ( $pledges >= $threshold ) ? $pledges : 0,
            ];
        }
    }

    ob_start(); ?>
    <div class="july3-map-wrap" style="margin:28px 0;">
        <div style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:16px;align-items:center;">
            <button type="button" class="j3-pill" onclick="july3FilterMap('all')" style="background:#0b0f19;color:#fff;">🌍 All Pins (<?php echo count($pins); ?>)</button>
            <button type="button" class="j3-pill" onclick="july3FilterMap('event')" style="background:#f3e8ff;color:#6b21a8;">🎤 Talks, Town Halls & Trainings</button>
            <button type="button" class="j3-pill" onclick="july3FilterMap('confirmed')" style="background:#d1fae5;color:#065f46;">✅ Confirmed Assemblies</button>
            <button type="button" class="j3-pill" onclick="july3FilterMap('prep')" style="background:#fef3c7;color:#92400e;">⏳ Assemblies in Prep</button>
            <button type="button" class="j3-pill" onclick="july3FilterMap('capital')" style="background:#ffe4e6;color:#be123c;">🔥 July 3 Capital Convergences</button>
        </div>
        <div id="july3-osm-map" style="height:520px;width:100%;border-radius:20px;box-shadow:0 20px 45px -15px rgba(15,23,42,0.18);overflow:hidden;"></div>
    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var map = L.map('july3-osm-map').setView([35.0, -2.0], 3);
        L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
            attribution: '&copy; OpenStreetMap &copy; CARTO'
        }).addTo(map);

        var rawPins = <?php echo wp_json_encode( $pins ); ?>;
        var markers = [];

        window.july3FilterMap = function(filterType) {
            markers.forEach(function(m) { map.removeLayer(m); });
            markers = [];
            rawPins.forEach(function(p) {
                if (filterType !== 'all' && p.type !== filterType) return;
                var colors = { capital: '#ff2a5f', confirmed: '#10b981', prep: '#f59e0b', event: '#8b5cf6' };
                var badges = {
                    capital: '🔥 July 3 Capital Convergence',
                    confirmed: '✅ Confirmed Citizen Assembly',
                    prep: '⏳ Assembly in Preparation',
                    event: '🎤 Public Talk / Town Hall / Training'
                };
                var m = L.circleMarker([p.lat, p.lng], {
                    radius: p.type === 'capital' ? 12 : 9,
                    fillColor: colors[p.type] || '#10b981',
                    color: '#ffffff',
                    weight: 2.5,
                    fillOpacity: 0.95
                }).addTo(map);
                var html = '<div style="font-family:Inter,sans-serif;line-height:1.45;padding:4px;"><strong style="font-size:15px;">' + p.title + '</strong><br><span style="font-size:12px;font-weight:600;color:#64748b;">' + (badges[p.type] || '') + '</span><br>';
                if (p.meetup) html += '📍 ' + p.meetup + '<br>';
                if (p.date) html += '🗓️ <strong>' + p.date + '</strong><br>';
                if (p.pledges > 0) html += '✋ <strong>' + p.pledges + '+</strong> Pledged<br>';
                if (p.chat) html += '<a href="' + p.chat + '" target="_blank" rel="noopener" style="display:inline-block;margin-top:8px;padding:6px 12px;background:#0b0f19;color:#fff;text-decoration:none;border-radius:8px;font-size:12px;font-weight:600;">🔗 Event Details / Join Group →</a>';
                html += '</div>';
                m.bindPopup(html);
                markers.push(m);
            });
        };
        july3FilterMap('all');
    });
    </script>
    <?php
    return ob_get_clean();
});

// Shortcode: [teamup_calendar] — Embeds the live 101 Demands Teamup Calendar!
add_shortcode( 'teamup_calendar', function() {
    return '<div style="margin:24px 0;border-radius:20px;overflow:hidden;box-shadow:0 15px 35px -10px rgba(15,23,42,0.12);"><iframe src="https://teamup.com/kswvbpogo3pf6txkut?showProfileAndInfo=0&showSidepanel=1&showViewSelector=1&showMenu=1" style="width:100%;height:620px;border:none;" loading="lazy"></iframe></div>';
});

// Shortcode: [demands_voting_deck]
add_shortcode( 'demands_voting_deck', function() {
    $demands = get_posts([ 'post_type' => 'mobilization_demand', 'posts_per_page' => -1, 'post_status' => 'publish' ]);
    $items   = [];
    foreach ( $demands as $d ) {
        $a   = (int) get_post_meta( $d->ID, '_demand_votes_agree', true );
        $dis = (int) get_post_meta( $d->ID, '_demand_votes_disagree', true );
        $tot = max( 1, $a + $dis );
        $items[] = [
            'id'         => $d->ID,
            'title'      => $d->post_title,
            'content'    => wp_strip_all_tags( $d->post_excerpt ?: $d->post_content ),
            'origin'     => get_post_meta( $d->ID, '_demand_origin', true ) ?: 'House of the People Charter',
            'assemblies' => (int) ( get_post_meta( $d->ID, '_demand_assemblies_count', true ) ?: 1 ),
            'agree'      => $a,
            'pct'        => round( ( $a / $tot ) * 100 ),
        ];
    }
    ob_start(); ?>
    <div class="july3-voting-engine" style="margin:32px 0;">
        <div style="background:linear-gradient(135deg,#0b0f19 0%,#1e293b 100%);color:#fff;border-radius:20px;padding:28px;margin-bottom:28px;box-shadow:0 20px 40px -15px rgba(15,23,42,0.25);">
            <label for="july3-demand-search" style="display:block;font-family:'Space Grotesk',sans-serif;font-weight:700;font-size:20px;margin-bottom:10px;">
                🔍 What must be in the People's Constitution? Start typing your demand:
            </label>
            <input type="text" id="july3-demand-search" placeholder="Search or propose: e.g., Tax wealth not work, Future Generations Act, housing, anti-corruption..." style="width:100%;padding:15px 20px;font-size:16px;border:none;border-radius:12px;background:rgba(255,255,255,0.95);color:#0f172a;box-sizing:border-box;outline:none;">
            <div id="july3-duplicate-matches" style="margin-top:14px;display:none;color:#fde68a;font-size:14px;"></div>
        </div>

        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:24px;">
            <?php foreach ( $items as $item ) : ?>
                <div class="j3-card july3-demand-card" data-title="<?php echo esc_attr( strtolower( $item['title'] . ' ' . $item['content'] ) ); ?>" style="display:flex;flex-direction:column;justify-content:space-between;">
                    <div>
                        <div style="display:inline-block;padding:4px 12px;border-radius:99px;background:#fff1f2;color:#e11d48;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:12px;">
                            🏛️ <?php echo esc_html( $item['assemblies'] ); ?> Assemblies • <?php echo esc_html( $item['origin'] ); ?>
                        </div>
                        <h3 style="margin:0 0 10px;font-size:20px;line-height:1.3;color:#0f172a;"><?php echo esc_html( $item['title'] ); ?></h3>
                        <?php if ( $item['content'] ) : ?>
                            <p style="font-size:14.5px;color:#475569;line-height:1.55;margin:0;"><?php echo esc_html( $item['content'] ); ?></p>
                        <?php endif; ?>
                    </div>
                    <div style="margin-top:20px;padding-top:16px;border-top:1px solid #f1f5f9;">
                        <div id="july3-vote-bar-<?php echo esc_attr( $item['id'] ); ?>" style="font-size:13px;font-weight:600;color:#059669;margin-bottom:12px;">
                            📊 Online Citizen Pulse: <?php echo esc_html( $item['pct'] ); ?>% Agree (<?php echo esc_html( number_format( $item['agree'] ) ); ?> 👍)
                        </div>
                        <div style="display:flex;gap:8px;">
                            <button type="button" onclick="july3Vote(<?php echo esc_attr( $item['id'] ); ?>,'agree',this)" style="flex:1;padding:10px;background:#ecfdf5;color:#065f46;border:none;border-radius:10px;font-weight:700;cursor:pointer;">👍 Agree</button>
                            <button type="button" onclick="july3Vote(<?php echo esc_attr( $item['id'] ); ?>,'disagree',this)" style="flex:1;padding:10px;background:#fff1f2;color:#9f1239;border:none;border-radius:10px;font-weight:700;cursor:pointer;">👎 Disagree</button>
                            <button type="button" onclick="this.closest('.july3-demand-card').style.opacity='0.35';" style="padding:10px 14px;background:#f1f5f9;color:#64748b;border:none;border-radius:10px;font-weight:600;cursor:pointer;">⏭️ Skip</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <script>
    (function(){
        var searchInput = document.getElementById('july3-demand-search');
        var matchBox = document.getElementById('july3-duplicate-matches');
        if (searchInput) {
            searchInput.addEventListener('input', function() {
                var q = this.value.toLowerCase().trim();
                var cards = document.querySelectorAll('.july3-demand-card');
                var matches = 0;
                cards.forEach(function(c) {
                    var text = c.getAttribute('data-title') || '';
                    if (!q || text.indexOf(q) !== -1) {
                        c.style.display = 'flex';
                        if (q.length > 2) matches++;
                    } else {
                        c.style.display = 'none';
                    }
                });
                if (q.length > 2) {
                    matchBox.style.display = 'block';
                    matchBox.innerHTML = matches > 0
                        ? '✨ <strong>Found ' + matches + ' matching assembly demand(s) below!</strong> Add your vote below to strengthen consensus.'
                        : '💡 <strong>New proposal!</strong> No exact match found yet — bring this to your local Assembly to add to the Charter.';
                } else {
                    matchBox.style.display = 'none';
                }
            });
        }
        window.july3Vote = function(postId, voteType, btn) {
            var fd = new FormData();
            fd.append('action', 'july3_cast_vote');
            fd.append('post_id', postId);
            fd.append('vote', voteType);
            fetch('<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>', { method: 'POST', body: fd })
                .then(function(r){ return r.json(); })
                .then(function(res){
                    if (res.success) {
                        var bar = document.getElementById('july3-vote-bar-' + postId);
                        if (bar) bar.innerHTML = '✅ Vote recorded! Online Pulse: ' + res.data.pct + '% Agree (' + res.data.agree + ' 👍)';
                        btn.disabled = true;
                    }
                });
        };
    })();
    </script>
    <?php
    return ob_get_clean();
});

// Shortcode: [coalition_logo_wall]
add_shortcode( 'coalition_logo_wall', function() {
    $orgs = get_posts([ 'post_type' => 'mobilization_org', 'posts_per_page' => -1, 'post_status' => 'publish' ]);
    ob_start(); ?>
    <div class="july3-logo-wall" style="margin:30px 0;">
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:18px;">
            <?php foreach ( $orgs as $o ) :
                $web  = get_post_meta( $o->ID, '_org_website', true ) ?: get_permalink( $o->ID );
                $logo = get_the_post_thumbnail_url( $o->ID, 'medium' ) ?: get_post_meta( $o->ID, '_org_logo_url', true );
                $regs = wp_get_post_terms( $o->ID, 'mobilization_region', [ 'fields' => 'names' ] );
                ?>
                <a href="<?php echo esc_url( $web ); ?>" target="_blank" rel="noopener" class="j3-card" style="padding:20px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-decoration:none;color:#0f172a;min-height:110px;text-align:center;">
                    <?php if ( $logo ) : ?>
                        <img src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( $o->post_title ); ?>" loading="lazy" style="max-width:140px;max-height:65px;object-fit:contain;margin-bottom:10px;">
                    <?php endif; ?>
                    <strong style="font-size:14px;"><?php echo esc_html( $o->post_title ); ?></strong>
                    <?php if ( $regs ) : ?>
                        <span style="font-size:11px;color:#64748b;margin-top:4px;"><?php echo esc_html( implode( ', ', $regs ) ); ?></span>
                    <?php endif; ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
});

/**
 * ============================================================================
 * MODULE 6: 1-CLICK REAL DATA SEEDER (Countries + House of the People + Totnes)
 * ============================================================================
 */
add_action( 'admin_menu', function() {
    add_menu_page( 'Country CRM & Data Seeder', '🌍 Country CRM', 'edit_posts', 'july3-country-crm', 'july3_render_crm_page', 'dashicons-admin-site-alt3', 25 );
});

add_action( 'admin_init', function() {
    if ( isset( $_POST['july3_seed_real_data'] ) && current_user_can( 'manage_options' ) ) {
        check_admin_referer( 'july3_seed_action' );

        // 1. Pre-populate Global Countries List
        $countries = [
            'United Kingdom', 'France', 'Spain', 'Germany', 'Ireland', 'Italy', 'Netherlands', 'Belgium', 'Sweden', 'Poland',
            'Colombia', 'Brazil', 'Argentina', 'Chile', 'Mexico', 'Peru', 'Ecuador',
            'Kenya', 'South Africa', 'Nigeria', 'Ghana', 'Senegal', 'Uganda', 'Tanzania', 'DR Congo',
            'India', 'Bangladesh', 'Philippines', 'Indonesia', 'Pakistan', 'Nepal', 'Malaysia',
            'United States', 'Canada', 'Australia', 'New Zealand', 'Global / International'
        ];
        foreach ( $countries as $c ) {
            if ( ! term_exists( $c, 'mobilization_region' ) ) {
                wp_insert_term( $c, 'mobilization_region' );
            }
        }

        // 2. Seed the 5 Real Demands from House of the People (houseofthepeople.uk) + 101st Demand
        $demands_data = [
            [
                'title'      => '1. Tax Wealth, Not Work: Close Tax Havens & End Super-Rich Loopholes',
                'content'    => 'Remove tax loopholes and close tax havens. End pension tax subsidies for the wealthy, charge National Insurance equivalent on investment income over £5,000/year, and apply VAT to financial and banking services.',
                'origin'     => 'House of the People — The People\'s Charter',
                'assemblies' => 42,
                'agree'      => 2840,
            ],
            [
                'title'      => '2. Slash Political Corruption: Ban Corporate Lobbying & Second Jobs for MPs',
                'content'    => 'Strengthen and strictly enforce anti-corruption laws across politics—prohibiting corporate lobbying, political gifting, revolving-door appointments, and second jobs for elected representatives.',
                'origin'     => 'House of the People — The People\'s Charter',
                'assemblies' => 39,
                'agree'      => 2690,
            ],
            [
                'title'      => '3. A Future Generations Act: A Law Above All Laws Choosing Life Over GDP',
                'content'    => 'Implement a foundational Future Generations Act ensuring all government policy prioritises human well-being, ecological restoration, climate stability, and nature over short-term GDP growth.',
                'origin'     => 'House of the People — The People\'s Charter',
                'assemblies' => 45,
                'agree'      => 3120,
            ],
            [
                'title'      => '4. End Complicity in Genocide & Unjust War: Total Arms & Trade Embargo',
                'content'    => 'Enforce an immediate, comprehensive embargo on arms sales, military trade, and diplomatic cover for any state violating international law and human rights.',
                'origin'     => 'House of the People — The People\'s Charter',
                'assemblies' => 38,
                'agree'      => 2510,
            ],
            [
                'title'      => '5. Decommodify Housing & Reclaim Community Spaces',
                'content'    => 'Enshrine structural renters\' rights and rent caps, and empower local councils to repurchase empty properties, disused buildings, and holiday homes to build green council housing and community spaces.',
                'origin'     => 'House of the People — The People\'s Charter',
                'assemblies' => 41,
                'agree'      => 2780,
            ],
            [
                'title'      => 'The 101st Demand: Establish a Permanent, Binding House of Citizens',
                'content'    => 'Create permanent, sortition-selected Citizen Assemblies with binding power to set the legislative agenda and hold governments accountable to the People\'s Charter.',
                'origin'     => 'The 101st Demand — Global Assembly Mandate',
                'assemblies' => 64,
                'agree'      => 3890,
            ],
        ];

        foreach ( $demands_data as $d ) {
            if ( ! get_page_by_title( $d['title'], OBJECT, 'mobilization_demand' ) ) {
                $pid = wp_insert_post([
                    'post_type'    => 'mobilization_demand',
                    'post_title'   => $d['title'],
                    'post_content' => $d['content'],
                    'post_excerpt' => $d['content'],
                    'post_status'  => 'publish',
                ]);
                update_post_meta( $pid, '_demand_origin', $d['origin'] );
                update_post_meta( $pid, '_demand_assemblies_count', $d['assemblies'] );
                update_post_meta( $pid, '_demand_votes_agree', $d['agree'] );
                update_post_meta( $pid, '_demand_votes_disagree', 45 );
                update_post_meta( $pid, '_demand_in_constitution', 'yes' );
                wp_set_object_terms( $pid, 'United Kingdom', 'mobilization_region' );
            }
        }

        // 3. Seed Real Teamup Events & Assemblies (Totnes Town Hall, Manchester, etc.)
        $events_data = [
            [
                'title'  => '🔥 Totnes: Public \'101 Demands\' Town Hall Gathering',
                'type'   => 'event',
                'lat'    => '50.4312',
                'lng'    => '-3.6844',
                'meetup' => 'Totnes Civic Hall, High St, Totnes',
                'date'   => 'Fri 13 Nov 2026, 7:00pm – 9:30pm',
                'chat'   => 'https://teamup.com/kswvbpogo3pf6txkut',
                'region' => 'United Kingdom',
            ],
            [
                'title'  => '🏛️ Manchester: House of the People Regional Assembly',
                'type'   => 'confirmed',
                'lat'    => '53.4808',
                'lng'    => '-2.2426',
                'meetup' => 'Central Manchester Venue (See Teamup Calendar)',
                'date'   => 'Sat 28 Nov 2026',
                'chat'   => 'https://teamup.com/kswvbpogo3pf6txkut',
                'region' => 'United Kingdom',
            ],
            [
                'title'  => '🔥 London: July 3 Capital Mass Mobilization',
                'type'   => 'capital',
                'lat'    => '51.5007',
                'lng'    => '-0.1246',
                'meetup' => 'Parliament Square / Central London Convergence',
                'date'   => 'Sat 3 July 2027',
                'chat'   => 'https://teamup.com/kswvbpogo3pf6txkut',
                'region' => 'United Kingdom',
            ],
            [
                'title'  => '🔥 Paris: Convergence Nationale & Plan de Reconstruction',
                'type'   => 'capital',
                'lat'    => '48.8566',
                'lng'    => '2.3522',
                'meetup' => 'Place de la République, Paris',
                'date'   => '3 July 2027',
                'chat'   => 'https://26septembre.org',
                'region' => 'France',
            ],
        ];

        foreach ( $events_data as $e ) {
            if ( ! get_page_by_title( $e['title'], OBJECT, 'mobilization_hub' ) ) {
                $hid = wp_insert_post([
                    'post_type'   => 'mobilization_hub',
                    'post_title'  => $e['title'],
                    'post_status' => 'publish',
                ]);
                update_post_meta( $hid, '_hub_type', $e['type'] );
                update_post_meta( $hid, '_hub_lat', $e['lat'] );
                update_post_meta( $hid, '_hub_lng', $e['lng'] );
                update_post_meta( $hid, '_hub_meetup', $e['meetup'] );
                update_post_meta( $hid, '_hub_next_date', $e['date'] );
                update_post_meta( $hid, '_hub_chat_url', $e['chat'] );
                wp_set_object_terms( $hid, $e['region'], 'mobilization_region' );
            }
        }

        flush_rewrite_rules();
        wp_safe_redirect( admin_url( 'admin.php?page=july3-country-crm&seeded=1' ) );
        exit;
    }
});

function july3_render_crm_page() {
    ?>
    <div class="wrap">
        <h1>🌍 101 Demands — Country CRM, CSV Exporter & Real Data Seeder</h1>
        <?php if ( isset( $_GET['seeded'] ) ) : ?>
            <div class="notice notice-success is-dismissible"><p><strong>🎉 Boom! Pre-populated 37 Countries, all 5 House of the People Charter Demands, and the Totnes / Manchester / London Teamup Events!</strong></p></div>
        <?php endif; ?>

        <div style="background:#0b0f19;color:#fff;border-radius:14px;padding:24px;max-width:780px;margin:20px 0;">
            <h2 style="color:#fff;margin-top:0;">🚀 1-Click Starter Data Seeder</h2>
            <p style="color:#cbd5e1;">Click below to pre-populate the global <strong>Countries & Regions</strong> checklist (so you never have to type countries manually), the <strong>5 House of the People Demands</strong>, and the upcoming <strong>Totnes Town Hall (13 Nov) & Teamup Events</strong>.</p>
            <form method="post">
                <?php wp_nonce_field( 'july3_seed_action' ); ?>
                <button type="submit" name="july3_seed_real_data" value="1" class="button button-primary button-hero" style="background:#ff2a5f;border-color:#ff2a5f;">🚀 Load Countries, House of the People 5 Demands & Totnes/Teamup Events</button>
            </form>
        </div>
    </div>
    <?php
}