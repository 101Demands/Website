<?php
/**
 * Plugin Name: July 3 Global Mobilization & 101 Demands Core
 * Plugin URI:  https://101demands.org
 * Description: Open-Source (FOSS) mobilization engine: Warm Rebel House Style, Live Signatory & Org Appeal Form, OpenStreetMap (Free Tiles), Teamup Calendar, 101 Demands Voting Deck, Coalition Logo Wall, and Country CRM.
 * Version:     0.4.0
 * Author:      101 Demands Global Tech Collective
 * License:     GPL-3.0+
 * Text Domain: july3-core
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ============================================================================
 * MODULE 1: CUSTOM POST TYPES, SIGNATORIES & TAXONOMIES
 * ============================================================================
 */
function july3_register_all_types() {

    register_taxonomy( 'mobilization_region', [ 'mobilization_hub', 'mobilization_org', 'mobilization_demand', 'mobilization_signer' ], [
        'labels'            => [ 'name' => 'Countries & Regions', 'singular_name' => 'Country / Region' ],
        'public'            => true,
        'hierarchical'      => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,
    ]);

    register_taxonomy( 'mobilization_pillar', [ 'mobilization_demand', 'mobilization_org' ], [
        'labels'            => [ 'name' => 'Pillars & Sectors', 'singular_name' => 'Pillar / Sector' ],
        'public'            => true,
        'hierarchical'      => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,
    ]);

    register_post_type( 'mobilization_hub', [
        'labels'       => [ 'name' => 'Assemblies & Events', 'singular_name' => 'Assembly / Event' ],
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => [ 'slug' => 'assemblies' ],
        'menu_icon'    => 'dashicons-location-alt',
        'supports'     => [ 'title', 'editor', 'custom-fields' ],
        'show_in_rest' => true,
    ]);

    register_post_type( 'mobilization_org', [
        'labels'       => [ 'name' => 'Coalition Orgs', 'singular_name' => 'Coalition Organisation' ],
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => [ 'slug' => 'coalition' ],
        'menu_icon'    => 'dashicons-groups',
        'supports'     => [ 'title', 'editor', 'thumbnail', 'custom-fields' ],
        'show_in_rest' => true,
    ]);

    register_post_type( 'mobilization_demand', [
        'labels'       => [ 'name' => '101 Demands', 'singular_name' => 'Demand / Measure' ],
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => [ 'slug' => 'demands' ],
        'menu_icon'    => 'dashicons-megaphone',
        'supports'     => [ 'title', 'editor', 'excerpt', 'custom-fields' ],
        'show_in_rest' => true,
    ]);

    // CPT 4: Individual Appeal Signatories (Private CRM list)
    register_post_type( 'mobilization_signer', [
        'labels'       => [ 'name' => 'Appeal Signatories', 'singular_name' => 'Signatory' ],
        'public'       => false,
        'show_ui'      => true,
        'menu_icon'    => 'dashicons-edit-page',
        'supports'     => [ 'title', 'custom-fields' ],
    ]);

    if ( get_option( 'july3_rewrite_version' ) !== '0.4.0' ) {
        flush_rewrite_rules();
        update_option( 'july3_rewrite_version', '0.4.0' );
    }
}
add_action( 'init', 'july3_register_all_types' );

/**
 * ============================================================================
 * MODULE 2: "26 SEPTEMBRE" WARM REBEL HOUSE STYLE + TOP NAV + LANGUAGE BAR
 * ============================================================================
 */
add_action( 'wp_head', function() {
    ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Caveat:wght@700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --j3-espresso: #1c130e;
            --j3-espresso-card: #291d16;
            --j3-cream: #fbf8f3;
            --j3-orange: #ea580c;
            --j3-amber: #f59e0b;
            --j3-green: #16a34a;
        }
        /* Hide default Twenty Twenty-Five header, footer & ugly 'Home' title */
        header.wp-block-template-part,
        footer.wp-block-template-part,
        .wp-block-post-title {
            display: none !important;
        }
        body {
            font-family: 'Plus Jakarta Sans', system-ui, sans-serif !important;
            background-color: var(--j3-cream) !important;
            color: var(--j3-espresso) !important;
            margin: 0 !important;
            padding: 0 !important;
        }
        /* Center-align and widen all containers */
        .wp-site-blocks,
        .wp-site-blocks > main,
        .entry-content,
        .wp-block-post-content {
            max-width: 100% !important;
            width: 100% !important;
            margin: 0 auto !important;
            padding: 0 !important;
        }
        .j3-container {
            max-width: 1180px;
            margin: 0 auto;
            padding: 0 24px;
            box-sizing: border-box;
        }
        .j3-poster-title {
            font-family: 'Anton', Impact, sans-serif !important;
            text-transform: uppercase;
            letter-spacing: 0.02em;
            line-height: 1.03 !important;
        }
        .j3-brush {
            font-family: 'Caveat', cursive !important;
            font-size: 32px;
            color: var(--j3-orange);
            line-height: 1.1;
        }
        /* Sticky Top Rebel Navbar */
        .j3-topbar {
            background: #120c08;
            color: #ffffff;
            padding: 14px 28px;
            position: sticky;
            top: 0;
            z-index: 9999;
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .j3-topbar-inner {
            max-width: 1280px;
            margin: 0 auto;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
        }
        .j3-nav-links {
            display: flex;
            flex-wrap: wrap;
            gap: 22px;
            align-items: center;
            justify-content: center;
        }
        .j3-nav-links a {
            color: #d6d3d1;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            transition: color 0.15s;
        }
        .j3-nav-links a:hover {
            color: var(--j3-amber);
        }
        .j3-btn-orange {
            background: var(--j3-orange);
            color: #ffffff !important;
            padding: 10px 22px;
            border-radius: 999px;
            font-weight: 700;
            font-size: 14px;
            text-decoration: none;
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 4px 14px rgba(234, 88, 12, 0.35);
            transition: transform 0.15s, background 0.15s;
        }
        .j3-btn-orange:hover {
            background: #c2410c;
            transform: translateY(-1px);
        }
        .j3-lang-select {
            background: #291d16;
            color: #fff;
            border: 1px solid rgba(255,255,255,0.2);
            padding: 8px 14px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
        }
    </style>
    <?php
});

// Inject Top Navigation + Language Selector + Signatory Counter Bar automatically at top of page
add_action( 'wp_body_open', function() {
    $org_count    = wp_count_posts( 'mobilization_org' )->publish ?? 1;
    $signer_count = ( wp_count_posts( 'mobilization_signer' )->publish ?? 0 ) + 1420; // Includes initial paper/street sheets
    ?>
    <div class="j3-topbar">
        <div class="j3-topbar-inner">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="display:flex;align-items:center;gap:10px;text-decoration:none;color:#fff;">
                <span style="background:var(--j3-orange);color:#fff;font-family:'Anton',sans-serif;padding:4px 10px;border-radius:6px;font-size:18px;letter-spacing:1px;">101 DEMANDS</span>
                <span style="background:var(--j3-amber);color:#120c08;font-weight:800;font-size:12px;padding:3px 10px;border-radius:99px;">JULY 3 GLOBAL</span>
            </a>
            <nav class="j3-nav-links">
                <a href="#appeal" data-i18n="nav_appeal">The Appeal</a>
                <a href="#map" data-i18n="nav_map">The Map &amp; Assemblies</a>
                <a href="#calendar" data-i18n="nav_cal">Key Dates</a>
                <a href="#demands" data-i18n="nav_demands">The 101 Demands</a>
                <a href="#coalition" data-i18n="nav_orgs">Signatory Orgs</a>
            </nav>
            <div style="display:flex;align-items:center;gap:12px;">
                <select id="j3-lang-switcher" class="j3-lang-select" onchange="july3SwitchLang(this.value)" aria-label="Choose Language">
                    <option value="en">🌍 Choose Language (EN)</option>
                    <option value="fr">🌍 Français (FR)</option>
                    <option value="es">🌍 Español (ES)</option>
                    <option value="pt">🌍 Português (PT)</option>
                    <option value="sw">🌍 Kiswahili (SW)</option>
                </select>
                <a href="#sign-appeal" class="j3-btn-orange" data-i18n="btn_sign">✍️ Sign the appeal →</a>
            </div>
        </div>
    </div>
    <div style="background:#f3ede2;text-align:center;padding:10px 16px;font-size:15px;border-bottom:1px solid rgba(28,19,14,0.08);">
        <strong style="font-family:'Anton',sans-serif;font-size:20px;letter-spacing:0.5px;"><?php echo esc_html( number_format( $signer_count ) ); ?></strong> <span data-i18n="bar_signatories">signatories, of which</span>
        <strong style="font-family:'Anton',sans-serif;font-size:20px;letter-spacing:0.5px;margin-left:4px;"><?php echo esc_html( number_format( $org_count ) ); ?></strong> <span data-i18n="bar_orgs">coalition organizations</span>
    </div>
    <script>
    var j3Translations = {
        en: { nav_appeal:"The Appeal", nav_map:"The Map & Assemblies", nav_cal:"Key Dates", nav_demands:"The 101 Demands", nav_orgs:"Signatory Orgs", btn_sign:"✍️ Sign the appeal →", bar_signatories:"signatories, of which", bar_orgs:"coalition organizations" },
        fr: { nav_appeal:"L'Appel", nav_map:"La Carte & Assemblées", nav_cal:"Le Calendrier", nav_demands:"Les 101 Mesures", nav_orgs:"Organisations", btn_sign:"✍️ Signer l'appel →", bar_signatories:"signataires dont", bar_orgs:"organisations" },
        es: { nav_appeal:"El Llamado", nav_map:"El Mapa y Asambleas", nav_cal:"Fechas Clave", nav_demands:"Las 101 Demandas", nav_orgs:"Organizaciones", btn_sign:"✍️ Firmar el llamado →", bar_signatories:"firmantes, de los cuales", bar_orgs:"organizaciones" },
        pt: { nav_appeal:"O Apelo", nav_map:"O Mapa e Assembleias", nav_cal:"Datas", nav_demands:"As 101 Exigências", nav_orgs:"Organizações", btn_sign:"✍️ Assinar o apelo →", bar_signatories:"signatários, dos quais", bar_orgs:"organizações" },
        sw: { nav_appeal:"Wito", nav_map:"Ramani na Mabaraza", nav_cal:"Kalenda", nav_demands:"Madai 101", nav_orgs:"Mashirika", btn_sign:"✍️ Tia Saini Wito →", bar_signatories:"waliotia saini, ikiwemo", bar_orgs:"mashirika" }
    };
    window.july3SwitchLang = function(lang) {
        var dict = j3Translations[lang] || j3Translations.en;
        document.querySelectorAll('[data-i18n]').forEach(function(el){
            var k = el.getAttribute('data-i18n');
            if (dict[k]) el.textContent = dict[k];
        });
    };
    </script>
    <?php
});

/**
 * ============================================================================
 * MODULE 3: SHORTCODE — [mobilization_hero_and_appeal]
 * Replicates & betters Ben's 26septembre Hero Card + 2-Tab "Sign the Appeal" Form!
 * ============================================================================
 */
add_action( 'wp_ajax_july3_submit_appeal', 'july3_handle_appeal_submit' );
add_action( 'wp_ajax_nopriv_july3_submit_appeal', 'july3_handle_appeal_submit' );
function july3_handle_appeal_submit() {
    $mode    = sanitize_text_field( $_POST['mode'] ?? 'individual' );
    $fname   = sanitize_text_field( $_POST['fname'] ?? '' );
    $lname   = sanitize_text_field( $_POST['lname'] ?? '' );
    $email   = sanitize_email( $_POST['email'] ?? '' );
    $country = sanitize_text_field( $_POST['country'] ?? '' );
    $orgname = sanitize_text_field( $_POST['org_name'] ?? '' );
    $orgweb  = esc_url_raw( $_POST['org_web'] ?? '' );
    $orglogo = esc_url_raw( $_POST['org_logo'] ?? '' );

    if ( $mode === 'org' && $orgname ) {
        $oid = wp_insert_post([
            'post_type'   => 'mobilization_org',
            'post_title'  => $orgname,
            'post_status' => 'publish', // Instant demo visibility; can switch to 'pending' for moderation
        ]);
        update_post_meta( $oid, '_org_website', $orgweb );
        update_post_meta( $oid, '_org_logo_url', $orglogo );
        update_post_meta( $oid, '_crm_org_contact', trim( $fname . ' ' . $lname ) );
        update_post_meta( $oid, '_crm_org_email', $email );
        if ( $country ) wp_set_object_terms( $oid, $country, 'mobilization_region' );
        wp_send_json_success([ 'msg' => '🎉 Thank you! ' . $orgname . ' has been added to the Coalition Wall!' ]);
    } else {
        $sid = wp_insert_post([
            'post_type'   => 'mobilization_signer',
            'post_title'  => trim( $fname . ' ' . $lname ) ?: 'Citizen Signatory',
            'post_status' => 'publish',
        ]);
        update_post_meta( $sid, '_signer_email', $email );
        if ( $country ) wp_set_object_terms( $sid, $country, 'mobilization_region' );
        wp_send_json_success([ 'msg' => '✊ Thank you for signing the Appeal! Check your inbox for local Assembly details.' ]);
    }
}

add_shortcode( 'mobilization_hero_and_appeal', function() {
    $org_count    = wp_count_posts( 'mobilization_org' )->publish ?? 1;
    $signer_count = ( wp_count_posts( 'mobilization_signer' )->publish ?? 0 ) + 1420;
    $pct          = min( 100, round( ( $signer_count / 10000 ) * 100 ) );
    $regions      = get_terms([ 'taxonomy' => 'mobilization_region', 'hide_empty' => false ]);

    ob_start(); ?>
    <!-- HERO CARD (Warm Espresso Gradient like 26septembre) -->
    <section id="appeal" style="padding:48px 20px 64px;text-align:center;">
        <div style="max-width:1060px;margin:0 auto;background:radial-gradient(circle at 75% 25%, #4a2511 0%, #1c130e 70%);color:#fff;border-radius:28px;padding:56px 40px;box-shadow:0 30px 60px -15px rgba(28,19,14,0.45);text-align:left;display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:40px;align-items:center;">
            
            <!-- Left Poster Badge -->
            <div style="background:#120c08;border-radius:22px;padding:36px 28px;text-align:center;box-shadow:0 20px 40px rgba(0,0,0,0.45);border:1px solid rgba(255,255,255,0.08);">
                <div style="color:#d6d3d1;font-size:13px;font-weight:700;letter-spacing:2px;text-transform:uppercase;">GLOBAL MOBILIZATION</div>
                <div class="j3-poster-title" style="font-size:52px;color:var(--j3-orange);margin:6px 0;">JULY 3</div>
                <div style="background:var(--j3-amber);color:#120c08;font-family:'Anton',sans-serif;font-size:22px;padding:8px 16px;border-radius:8px;margin:12px 0;text-transform:uppercase;">
                    « THE PEOPLE'S CONSTITUTION &amp; 101 DEMANDS »
                </div>
                <p style="font-size:13px;color:#a8a29e;margin:14px 0 0;line-height:1.5;">
                    📡 <strong>March 20–21:</strong> Global Assembly Link-Up<br>
                    🔥 <strong>July 3:</strong> Capital City Mass Demonstrations<br>
                    🗳️ <strong>Beyond:</strong> Global Elections Accountability Hub
                </p>
            </div>

            <!-- Right Hero Typography & Live Progress Bars -->
            <div>
                <div style="color:var(--j3-orange);font-size:12px;font-weight:800;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:10px;">
                    MOVEMENT OF CITIZEN ASSEMBLIES • MAJORITY WORLD &amp; GLOBE
                </div>
                <h1 class="j3-poster-title" style="font-size:54px;color:var(--j3-amber);margin:0 0 12px;">
                    FOR REAL DEMOCRACY, CLIMATE JUSTICE &amp; FUTURE GENERATIONS
                </h1>
                <div class="j3-poster-title" style="font-size:26px;color:#fff;margin-bottom:18px;">
                    FOR <span style="color:#84cc16;">LIFE</span>, FOR <span style="color:#f59e0b;">TAXING WEALTH</span>, FOR <span style="color:#38bdf8;">PEACE</span> AND <span style="color:#f43f5e;">CITIZEN ASSEMBLIES</span>
                </div>
                <p style="color:#d6d3d1;font-size:15px;line-height:1.6;margin-bottom:24px;">
                    We are not here to ask for crumbs from captured politicians. Across local town halls and citizen assemblies worldwide, we are drafting the People's Constitution—and converging on Capital Cities on July 3rd.
                </p>
                <div style="display:flex;flex-wrap:wrap;gap:12px;margin-bottom:28px;">
                    <a href="#sign-appeal" class="j3-btn-orange">✍️ I sign the appeal</a>
                    <a href="#demands" style="padding:10px 22px;border-radius:999px;border:1px solid rgba(255,255,255,0.3);color:#fff;text-decoration:none;font-weight:700;font-size:14px;">🗳️ Vote on the Demands</a>
                    <a href="#map" style="padding:10px 22px;border-radius:999px;border:1px solid rgba(245,158,11,0.5);color:var(--j3-amber);text-decoration:none;font-weight:700;font-size:14px;">🗺️ Find an Assembly</a>
                </div>

                <!-- Live Signatory Progress Bar -->
                <div style="border-top:1px solid rgba(255,255,255,0.12);padding-top:18px;">
                    <div style="display:flex;align-items:baseline;gap:8px;">
                        <span class="j3-poster-title" style="font-size:38px;color:var(--j3-orange);"><?php echo esc_html( number_format( $signer_count ) ); ?></span>
                        <span style="font-size:14px;color:#e7e5e4;"><strong>signatories</strong> &amp; assembly participants to date</span>
                    </div>
                    <div style="height:8px;background:rgba(255,255,255,0.12);border-radius:99px;margin:8px 0;overflow:hidden;">
                        <div style="width:<?php echo esc_attr( max( 12, $pct ) ); ?>%;height:100%;background:linear-gradient(90deg,var(--j3-orange),var(--j3-amber));border-radius:99px;"></div>
                    </div>
                    <div style="font-size:12px;color:#a8a29e;">
                        Including <strong><?php echo esc_html( number_format( $org_count ) ); ?></strong> signatory coalition organizations
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FULL-WIDTH DARK ESPRESSO "SIGN THE APPEAL" SECTION (Individual + Organization Tabs!) -->
    <section id="sign-appeal" style="background:var(--j3-espresso);color:#fff;padding:72px 24px;">
        <div style="max-width:1060px;margin:0 auto;display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:48px;align-items:center;">
            
            <!-- Left Callout Copy -->
            <div style="text-align:left;">
                <div style="color:var(--j3-orange);font-size:12px;font-weight:800;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:8px;">
                    SIGN THE APPEAL &amp; JOIN THE MOBILIZATION
                </div>
                <h2 class="j3-poster-title" style="font-size:52px;color:#fff;margin:0 0 12px;">
                    ADD YOUR <span style="color:var(--j3-orange);">SIGNATURE</span> TO THE CALL FOR JULY 3RD &amp; THE 101 DEMANDS.
                </h2>
                <div class="j3-brush" style="margin-bottom:24px;">Let us assemble and march for the living.</div>
                <p style="color:#d6d3d1;font-size:14.5px;line-height:1.7;">
                    📍 <strong>Step 1:</strong> Add your name or register your organization.<br>
                    🔒 <strong>Privacy-First:</strong> Hosted in Iceland on 1984. Zero tracking cookies, never sold or shared.<br>
                    🏛️ <strong>Step 2:</strong> Receive details of your nearest Local Assembly, Town Hall gathering, and July 3rd Capital Convergence.
                </p>
            </div>

            <!-- Right White Form Card with 2 Tabs: [ I sign ] | [ I sign up for an organization ] -->
            <div style="background:#fbf8f3;color:var(--j3-espresso);border-radius:24px;padding:32px;box-shadow:0 25px 50px -12px rgba(0,0,0,0.5);text-align:left;">
                <div style="display:flex;background:#e7e0d6;border-radius:12px;padding:4px;margin-bottom:22px;">
                    <button type="button" id="j3-tab-ind" onclick="july3SetAppealMode('individual')" style="flex:1;padding:10px;border:none;border-radius:9px;background:var(--j3-espresso);color:#fff;font-weight:700;cursor:pointer;">✋ I sign (Individual)</button>
                    <button type="button" id="j3-tab-org" onclick="july3SetAppealMode('org')" style="flex:1;padding:10px;border:none;border-radius:9px;background:transparent;color:var(--j3-espresso);font-weight:700;cursor:pointer;">🤝 I sign up an Organization</button>
                </div>

                <form id="j3-appeal-form" onsubmit="return july3SubmitAppeal(event)">
                    <input type="hidden" name="mode" id="j3-appeal-mode" value="individual">
                    
                    <div id="j3-org-fields" style="display:none;margin-bottom:14px;padding:14px;background:#fff;border-radius:12px;border:1px solid #e7e0d6;">
                        <label style="display:block;font-size:11px;font-weight:800;text-transform:uppercase;margin-bottom:4px;">Organization / Group Name *</label>
                        <input type="text" name="org_name" placeholder="e.g., Media Revolution, Local Climate Alliance..." style="width:100%;padding:10px;border-radius:8px;border:1px solid #d6d3d1;margin-bottom:10px;box-sizing:border-box;">
                        <label style="display:block;font-size:11px;font-weight:800;text-transform:uppercase;margin-bottom:4px;">Organization Website URL</label>
                        <input type="url" name="org_web" placeholder="https://..." style="width:100%;padding:10px;border-radius:8px;border:1px solid #d6d3d1;margin-bottom:10px;box-sizing:border-box;">
                        <label style="display:block;font-size:11px;font-weight:800;text-transform:uppercase;margin-bottom:4px;">Logo Image URL (Optional - or email to coordinator)</label>
                        <input type="url" name="org_logo" placeholder="https://.../logo.png" style="width:100%;padding:10px;border-radius:8px;border:1px solid #d6d3d1;box-sizing:border-box;">
                    </div>

                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
                        <div>
                            <label style="display:block;font-size:11px;font-weight:800;text-transform:uppercase;margin-bottom:4px;">First Name *</label>
                            <input type="text" name="fname" required placeholder="Camille" style="width:100%;padding:11px;border-radius:8px;border:1px solid #d6d3d1;background:#fff;box-sizing:border-box;">
                        </div>
                        <div>
                            <label style="display:block;font-size:11px;font-weight:800;text-transform:uppercase;margin-bottom:4px;">Last Name *</label>
                            <input type="text" name="lname" required placeholder="Dupont" style="width:100%;padding:11px;border-radius:8px;border:1px solid #d6d3d1;background:#fff;box-sizing:border-box;">
                        </div>
                    </div>

                    <div style="margin-bottom:12px;">
                        <label style="display:block;font-size:11px;font-weight:800;text-transform:uppercase;margin-bottom:4px;">Email Address *</label>
                        <input type="email" name="email" required placeholder="camille@example.org" style="width:100%;padding:11px;border-radius:8px;border:1px solid #d6d3d1;background:#fff;box-sizing:border-box;">
                    </div>

                    <div style="margin-bottom:16px;">
                        <label style="display:block;font-size:11px;font-weight:800;text-transform:uppercase;margin-bottom:4px;">Country / Region *</label>
                        <select name="country" style="width:100%;padding:11px;border-radius:8px;border:1px solid #d6d3d1;background:#fff;box-sizing:border-box;">
                            <option value="">🌍 Select Country / Region...</option>
                            <?php if ( ! is_wp_error( $regions ) ) : foreach ( $regions as $r ) : ?>
                                <option value="<?php echo esc_attr( $r->name ); ?>"><?php echo esc_html( $r->name ); ?></option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>

                    <button type="submit" class="j3-btn-orange" style="width:100%;justify-content:center;padding:14px;font-size:16px;">
                        ✍️ I sign the appeal
                    </button>
                    <div id="j3-appeal-feedback" style="margin-top:12px;font-weight:700;color:var(--j3-green);display:none;text-align:center;"></div>
                </form>
            </div>
        </div>
    </section>
    <script>
    window.july3SetAppealMode = function(mode) {
        document.getElementById('j3-appeal-mode').value = mode;
        var orgFields = document.getElementById('j3-org-fields');
        var tabInd = document.getElementById('j3-tab-ind');
        var tabOrg = document.getElementById('j3-tab-org');
        if (mode === 'org') {
            orgFields.style.display = 'block';
            tabOrg.style.background = '#1c130e'; tabOrg.style.color = '#fff';
            tabInd.style.background = 'transparent'; tabInd.style.color = '#1c130e';
        } else {
            orgFields.style.display = 'none';
            tabInd.style.background = '#1c130e'; tabInd.style.color = '#fff';
            tabOrg.style.background = 'transparent'; tabOrg.style.color = '#1c130e';
        }
    };
    window.july3SubmitAppeal = function(e) {
        e.preventDefault();
        var form = document.getElementById('j3-appeal-form');
        var fd = new FormData(form);
        fd.append('action', 'july3_submit_appeal');
        fetch('<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>', { method:'POST', body:fd })
            .then(function(r){ return r.json(); })
            .then(function(res){
                var fb = document.getElementById('j3-appeal-feedback');
                fb.style.display = 'block';
                fb.textContent = res.data ? res.data.msg : 'Thank you!';
                form.reset();
            });
        return false;
    };
    </script>
    <?php
    return ob_get_clean();
});

/**
 * ============================================================================
 * MODULE 4: SHORTCODE — [mobilization_map] (Fixed 100% Free OSM Tiles + Centered!)
 * ============================================================================
 */
add_shortcode( 'mobilization_map', function() {
    wp_enqueue_style( 'leaflet-css', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', [], '1.9.4' );
    wp_enqueue_script( 'leaflet-js', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', [], '1.9.4', true );

    $hubs = get_posts([ 'post_type' => 'mobilization_hub', 'posts_per_page' => -1, 'post_status' => 'publish' ]);
    $pins = [];
    foreach ( $hubs as $h ) {
        $lat = get_post_meta( $h->ID, '_hub_lat', true );
        $lng = get_post_meta( $h->ID, '_hub_lng', true );
        if ( $lat && $lng ) {
            $pins[] = [
                'title'  => $h->post_title,
                'lat'    => (float) $lat,
                'lng'    => (float) $lng,
                'type'   => get_post_meta( $h->ID, '_hub_type', true ) ?: 'confirmed',
                'meetup' => get_post_meta( $h->ID, '_hub_meetup', true ),
                'date'   => get_post_meta( $h->ID, '_hub_next_date', true ),
                'chat'   => get_post_meta( $h->ID, '_hub_chat_url', true ),
            ];
        }
    }

    ob_start(); ?>
    <section id="map" class="j3-container" style="padding:64px 24px;text-align:center;">
        <div style="color:var(--j3-orange);font-size:12px;font-weight:800;letter-spacing:1.5px;text-transform:uppercase;">LOCAL ASSEMBLIES, TOWN HALLS &amp; CONVERGENCES</div>
        <h2 class="j3-poster-title" style="font-size:46px;margin:6px 0 8px;">THE GLOBAL MOBILIZATION MAP</h2>
        <div class="j3-brush" style="margin-bottom:24px;">Find an assembly or public talk near you</div>

        <div style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:20px;justify-content:center;">
            <button type="button" onclick="july3FilterMap('all')" style="padding:9px 18px;border-radius:99px;border:none;background:var(--j3-espresso);color:#fff;font-weight:700;cursor:pointer;">🌍 All Pins (<?php echo count($pins); ?>)</button>
            <button type="button" onclick="july3FilterMap('event')" style="padding:9px 18px;border-radius:99px;border:none;background:#f3e8ff;color:#6b21a8;font-weight:700;cursor:pointer;">🎤 Talks, Town Halls &amp; Trainings</button>
            <button type="button" onclick="july3FilterMap('confirmed')" style="padding:9px 18px;border-radius:99px;border:none;background:#dcfce7;color:#166534;font-weight:700;cursor:pointer;">✅ Confirmed Assemblies</button>
            <button type="button" onclick="july3FilterMap('capital')" style="padding:9px 18px;border-radius:99px;border:none;background:#ffedd5;color:#c2410c;font-weight:700;cursor:pointer;">🔥 July 3 Capital Convergences</button>
        </div>
        <div id="july3-osm-map" style="height:520px;width:100%;border-radius:24px;box-shadow:0 25px 50px -12px rgba(28,19,14,0.18);overflow:hidden;text-align:left;"></div>
    </section>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var map = L.map('july3-osm-map').setView([51.5, -1.5], 5);
        // Pure OpenStreetMap standard tiles — 100% free, zero API keys ever required!
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        var rawPins = <?php echo wp_json_encode( $pins ); ?>;
        var markers = [];

        window.july3FilterMap = function(filterType) {
            markers.forEach(function(m) { map.removeLayer(m); });
            markers = [];
            rawPins.forEach(function(p) {
                if (filterType !== 'all' && p.type !== filterType) return;
                var colors = { capital: '#ea580c', confirmed: '#16a34a', prep: '#f59e0b', event: '#8b5cf6' };
                var m = L.circleMarker([p.lat, p.lng], {
                    radius: p.type === 'capital' ? 12 : 10,
                    fillColor: colors[p.type] || '#ea580c',
                    color: '#1c130e',
                    weight: 2.5,
                    fillOpacity: 0.95
                }).addTo(map);
                var html = '<div style="font-family:sans-serif;line-height:1.45;padding:4px;"><strong style="font-size:15px;">' + p.title + '</strong><br>';
                if (p.meetup) html += '📍 ' + p.meetup + '<br>';
                if (p.date) html += '🗓️ <strong>' + p.date + '</strong><br>';
                if (p.chat) html += '<a href="' + p.chat + '" target="_blank" rel="noopener" style="display:inline-block;margin-top:8px;padding:6px 12px;background:#ea580c;color:#fff;text-decoration:none;border-radius:8px;font-size:12px;font-weight:700;">🔗 Details &amp; RSVP →</a>';
                html += '</div>';
                m.bindPopup(html);
                markers.push(m);
            });
        };
        july3FilterMap('all');
    });
    </script>
    <?php
    return ob_get_clean();
});

// Shortcode: [teamup_calendar]
add_shortcode( 'teamup_calendar', function() {
    return '<section id="calendar" class="j3-container" style="padding:32px 24px 64px;text-align:center;">
        <div style="color:var(--j3-orange);font-size:12px;font-weight:800;letter-spacing:1.5px;text-transform:uppercase;">KEY DATES &amp; REGIONAL GATHERINGS</div>
        <h2 class="j3-poster-title" style="font-size:44px;margin:6px 0 20px;">THE MOBILIZATION CALENDAR</h2>
        <div style="border-radius:24px;overflow:hidden;box-shadow:0 20px 45px -12px rgba(28,19,14,0.16);background:#fff;"><iframe src="https://teamup.com/kswvbpogo3pf6txkut?showProfileAndInfo=0&showSidepanel=1&showViewSelector=1&showMenu=1" style="width:100%;height:600px;border:none;" loading="lazy"></iframe></div>
    </section>';
});

/**
 * ============================================================================
 * MODULE 5: SHORTCODE — [demands_voting_deck] (Alternating Espresso/Orange/Cream Cards!)
 * Replicates Ben's "01 / 02 / 03 Three plans and how to pay for them" section!
 * ============================================================================
 */
add_shortcode( 'demands_voting_deck', function() {
    $demands = get_posts([ 'post_type' => 'mobilization_demand', 'posts_per_page' => -1, 'post_status' => 'publish', 'orderby' => 'date', 'order' => 'ASC' ]);
    $items   = [];
    foreach ( $demands as $d ) {
        $a   = (int) get_post_meta( $d->ID, '_demand_votes_agree', true );
        $dis = (int) get_post_meta( $d->ID, '_demand_votes_disagree', true );
        $tot = max( 1, $a + $dis );
        $items[] = [
            'id'         => $d->ID,
            'title'      => $d->post_title,
            'content'    => wp_strip_all_tags( $d->post_excerpt ?: $d->post_content ),
            'origin'     => get_post_meta( $d->ID, '_demand_origin', true ) ?: 'House of the People Charter',
            'assemblies' => (int) ( get_post_meta( $d->ID, '_demand_assemblies_count', true ) ?: 1 ),
            'agree'      => $a,
            'pct'        => round( ( $a / $tot ) * 100 ),
        ];
    }

    // Alternating card palette inspired directly by 26septembre's 01 / 02 / 03 blocks!
    $palettes = [
        [ 'bg' => '#1c130e', 'text' => '#ffffff', 'num' => '#443024', 'accent' => '#ea580c', 'sub' => '#d6d3d1' ],
        [ 'bg' => '#ffffff', 'text' => '#1c130e', 'num' => '#e7e0d6', 'accent' => '#1c130e', 'sub' => '#57534e' ],
        [ 'bg' => '#ea580c', 'text' => '#1c130e', 'num' => '#fb923c', 'accent' => '#1c130e', 'sub' => '#291d16' ],
    ];

    ob_start(); ?>
    <section id="demands" class="j3-container" style="padding:64px 24px;text-align:center;">
        <div style="color:var(--j3-orange);font-size:12px;font-weight:800;letter-spacing:1.5px;text-transform:uppercase;">OUR REQUIREMENTS &amp; EMERGING CONSTITUTION</div>
        <h2 class="j3-poster-title" style="font-size:50px;margin:6px 0 4px;">THE PEOPLE'S CHARTER &amp; 101 DEMANDS</h2>
        <div class="j3-brush" style="margin-bottom:28px;">Deliberated in assemblies, voted by citizens</div>

        <!-- Live Duplicate Matcher Search Bar -->
        <div style="max-width:820px;margin:0 auto 36px;background:var(--j3-espresso);color:#fff;border-radius:20px;padding:24px 28px;box-shadow:0 20px 40px -15px rgba(28,19,14,0.3);">
            <label for="july3-demand-search" style="display:block;font-weight:700;font-size:16px;margin-bottom:10px;color:var(--j3-amber);">
                🔍 Have a demand? Start typing to check if an Assembly has already proposed it:
            </label>
            <input type="text" id="july3-demand-search" placeholder="Search or propose: e.g., Tax wealth, Future Generations Act, housing, corruption..." style="width:100%;padding:14px 18px;font-size:15px;border:none;border-radius:12px;background:#fbf8f3;color:#1c130e;box-sizing:border-box;">
            <div id="july3-duplicate-matches" style="margin-top:12px;display:none;color:#fde68a;font-size:14px;"></div>
        </div>

        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(330px,1fr));gap:24px;text-align:left;">
            <?php foreach ( $items as $idx => $item ) :
                $pal = $palettes[ $idx % 3 ];
                ?>
                <div class="july3-demand-card" data-title="<?php echo esc_attr( strtolower( $item['title'] . ' ' . $item['content'] ) ); ?>" style="background:<?php echo esc_attr( $pal['bg'] ); ?>;color:<?php echo esc_attr( $pal['text'] ); ?>;border-radius:22px;padding:30px;box-shadow:0 18px 38px -12px rgba(28,19,14,0.14);display:flex;flex-direction:column;justify-content:space-between;">
                    <div>
                        <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:10px;">
                            <span class="j3-poster-title" style="font-size:44px;color:<?php echo esc_attr( $pal['num'] ); ?>;"><?php echo esc_html( sprintf( '%02d', $idx + 1 ) ); ?></span>
                            <span style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:0.5px;opacity:0.85;">🏛️ <?php echo esc_html( $item['assemblies'] ); ?> Assemblies</span>
                        </div>
                        <h3 style="margin:0 0 12px;font-size:20px;font-weight:800;line-height:1.3;color:<?php echo esc_attr( $pal['accent'] ); ?>;text-decoration:underline;text-underline-offset:4px;">
                            <?php echo esc_html( preg_replace( '/^\d+\.\s*/', '', $item['title'] ) ); ?>
                        </h3>
                        <p style="font-size:14.5px;color:<?php echo esc_attr( $pal['sub'] ); ?>;line-height:1.6;margin:0;">
                            <?php echo esc_html( $item['content'] ); ?>
                        </p>
                    </div>
                    <div style="margin-top:22px;padding-top:16px;border-top:1px solid rgba(128,128,128,0.2);">
                        <div id="july3-vote-bar-<?php echo esc_attr( $item['id'] ); ?>" style="font-size:12.5px;font-weight:700;margin-bottom:10px;opacity:0.9;">
                            📊 <?php echo esc_html( $item['pct'] ); ?>% Agree (<?php echo esc_html( number_format( $item['agree'] ) ); ?> 👍)
                        </div>
                        <div style="display:flex;gap:8px;">
                            <button type="button" onclick="july3Vote(<?php echo esc_attr( $item['id'] ); ?>,'agree',this)" style="flex:1;padding:9px;background:rgba(255,255,255,0.92);color:#166534;border:none;border-radius:10px;font-weight:800;cursor:pointer;">👍 Agree</button>
                            <button type="button" onclick="july3Vote(<?php echo esc_attr( $item['id'] ); ?>,'disagree',this)" style="flex:1;padding:9px;background:rgba(255,255,255,0.92);color:#9f1239;border:none;border-radius:10px;font-weight:800;cursor:pointer;">👎 No</button>
                            <button type="button" onclick="this.closest('.july3-demand-card').style.opacity='0.35';" style="padding:9px 12px;background:rgba(0,0,0,0.15);color:inherit;border:none;border-radius:10px;font-weight:600;cursor:pointer;">Skip</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
    <?php
    return ob_get_clean();
});

// Shortcode: [coalition_logo_wall] (Centered!)
add_shortcode( 'coalition_logo_wall', function() {
    $orgs = get_posts([ 'post_type' => 'mobilization_org', 'posts_per_page' => -1, 'post_status' => 'publish' ]);
    ob_start(); ?>
    <section id="coalition" style="background:#f3ede2;padding:64px 24px;text-align:center;">
        <div class="j3-container">
            <div style="color:var(--j3-orange);font-size:12px;font-weight:800;letter-spacing:1.5px;text-transform:uppercase;">COALITION &amp; MOVEMENT PARTNERS</div>
            <h2 class="j3-poster-title" style="font-size:46px;margin:6px 0 8px;">SIGNATORY ORGANIZATIONS</h2>
            <div class="j3-brush" style="margin-bottom:28px;">Grassroots groups, unions &amp; alliances mobilizing together</div>

            <div style="display:flex;flex-wrap:wrap;justify-content:center;gap:20px;margin-bottom:28px;">
                <?php foreach ( $orgs as $o ) :
                    $web  = get_post_meta( $o->ID, '_org_website', true ) ?: get_permalink( $o->ID );
                    $logo = get_the_post_thumbnail_url( $o->ID, 'medium' ) ?: get_post_meta( $o->ID, '_org_logo_url', true );
                    $regs = wp_get_post_terms( $o->ID, 'mobilization_region', [ 'fields' => 'names' ] );
                    ?>
                    <a href="<?php echo esc_url( $web ); ?>" target="_blank" rel="noopener" style="width:200px;background:#fff;border-radius:18px;padding:22px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-decoration:none;color:var(--j3-espresso);box-shadow:0 12px 28px -8px rgba(28,19,14,0.1);">
                        <?php if ( $logo ) : ?>
                            <img src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( $o->post_title ); ?>" loading="lazy" style="max-width:140px;max-height:70px;object-fit:contain;margin-bottom:10px;">
                        <?php endif; ?>
                        <strong style="font-size:15px;"><?php echo esc_html( $o->post_title ); ?></strong>
                        <?php if ( $regs ) : ?>
                            <span style="font-size:11px;color:#78716c;margin-top:4px;"><?php echo esc_html( implode( ', ', $regs ) ); ?></span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
                <a href="#sign-appeal" onclick="july3SetAppealMode('org')" style="width:200px;background:rgba(234,88,12,0.08);border:2px dashed var(--j3-orange);border-radius:18px;padding:22px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-decoration:none;color:var(--j3-orange);font-weight:800;">
                    <span style="font-size:28px;margin-bottom:6px;">+</span>
                    <span>Add Your Organization</span>
                </a>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
});

// Keep Country CRM & Seeder Menu Active
add_action( 'admin_menu', function() {
    add_menu_page( 'Country CRM & Data Seeder', '🌍 Country CRM', 'edit_posts', 'july3-country-crm', 'july3_render_crm_page', 'dashicons-admin-site-alt3', 25 );
});
function july3_render_crm_page() {
    echo '<div class="wrap"><h1>🌍 101 Demands — Country CRM & Appeal Signatories</h1><p>Use the left menu to view <strong>Appeal Signatories</strong>, <strong>Coalition Orgs</strong>, <strong>Assemblies & Events</strong>, and <strong>101 Demands</strong>.</p></div>';
}