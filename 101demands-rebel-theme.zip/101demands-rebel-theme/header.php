<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="j3-topbar">
    <div style="display:flex;align-items:center;gap:10px;">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="j3-badge-orange" style="text-decoration:none;">101 DEMANDS</a>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="j3-badge-amber" style="text-decoration:none;">JULY 3 GLOBAL</a>
    </div>

    <nav class="j3-nav">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>">The Appeal</a>
        <a href="<?php echo esc_url( home_url( '/map-assemblies/' ) ); ?>">Map &amp; Assemblies</a>
        <a href="<?php echo esc_url( home_url( '/key-dates/' ) ); ?>">Key Dates</a>
        <a href="<?php echo esc_url( home_url( '/the-101-demands/' ) ); ?>">The 101 Demands</a>
        <a href="<?php echo esc_url( home_url( '/signatory-orgs/' ) ); ?>">Signatory Orgs</a>
        <a href="<?php echo esc_url( home_url( '/toolkits-flyers/' ) ); ?>">Toolkits &amp; Flyers</a>
        <a href="<?php echo esc_url( home_url( '/philosophy/' ) ); ?>">Philosophy</a>
    </nav>

    <div>
        <a href="<?php echo esc_url( home_url( '/#sign-appeal' ) ); ?>" class="j3-btn-orange">✍️ Sign the appeal →</a>
    </div>
</header>
<!-- === END OF HEADER.PHP === -->